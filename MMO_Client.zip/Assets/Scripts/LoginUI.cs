using UnityEngine;
using Unity.Netcode;

public class LoginUI : MonoBehaviour
{
    private string usernameInput = "";
    private string passwordInput = "";
    private string statusMessage = "";

    private void OnGUI()
    {
        // Nu afișăm interfața dacă suntem deja conectați ca Server/Client
        if (NetworkManager.Singleton != null && (NetworkManager.Singleton.IsClient || NetworkManager.Singleton.IsServer))
            return;

        float width = 320f;
        float height = 260f;
        Rect windowRect = new Rect((Screen.width - width) / 2, (Screen.height - height) / 2, width, height);

        GUILayout.BeginArea(windowRect, GUI.skin.box);
        GUILayout.Label("AUTHENTICATION", GUI.skin.label);

        GUILayout.Space(10);
        GUILayout.Label("Username:");
        usernameInput = GUILayout.TextField(usernameInput, 20);

        GUILayout.Label("Password:");
        passwordInput = GUILayout.PasswordField(passwordInput, '*', 20);

        GUILayout.Space(15);
        GUILayout.BeginHorizontal();

        // Buton Login
        if (GUILayout.Button("Login", GUILayout.Height(30)))
        {
            HandleLogin();
        }

        // Buton Register
        if (GUILayout.Button("Register", GUILayout.Height(30)))
        {
            HandleRegister();
        }

        GUILayout.EndHorizontal();

        GUILayout.Space(10);
        GUILayout.Label(statusMessage);

        GUILayout.EndArea();
    }

    private void HandleLogin()
    {
        if (string.IsNullOrEmpty(usernameInput) || string.IsNullOrEmpty(passwordInput))
        {
            statusMessage = "Completează toate câmpurile!";
            return;
        }

        if (DatabaseManager.Instance == null)
        {
            statusMessage = "Eroare: DatabaseManager nu a fost găsit în scenă!";
            Debug.LogError("DatabaseManager.Instance este NULL!");
            return;
        }

        if (DatabaseManager.Instance.LoginUser(usernameInput, passwordInput, out string userId))
        {
            statusMessage = "Autentificare reușită! Se conectează...";
            
            if (NetworkManager.Singleton != null)
            {
                NetworkManager.Singleton.StartHost();
            }
            else
            {
                statusMessage = "Eroare: NetworkManager lipsește din scenă!";
                Debug.LogError("NetworkManager.Singleton este NULL!");
            }
        }
        else
        {
            statusMessage = "Nume utilizator sau parolă incorectă.";
        }
    }

    private void HandleRegister()
    {
        if (string.IsNullOrEmpty(usernameInput) || string.IsNullOrEmpty(passwordInput))
        {
            statusMessage = "Completează toate câmpurile!";
            return;
        }

        if (DatabaseManager.Instance == null)
        {
            statusMessage = "Eroare: DatabaseManager nu a fost găsit!";
            return;
        }

        if (DatabaseManager.Instance.RegisterUser(usernameInput, passwordInput, out string error))
        {
            statusMessage = "Cont creat cu succes! Te poți conecta.";
        }
        else
        {
            statusMessage = $"Eroare: {error}";
        }
    }
}