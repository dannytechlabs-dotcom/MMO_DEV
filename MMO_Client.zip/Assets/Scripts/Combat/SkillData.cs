using System;
using UnityEngine;

// =====================================================================
//  CLASSES, WEAPONS, ELEMENTS and SKILL DATA
//  Original names (nothing here is copied from another game).
//  Tradition name: change TraditionName if you want something else.
// =====================================================================

public enum WeaponFamily { Any, Sword, Glaive, Bow }   // Glaive family = glaive (STR) and spear (INT)

public enum ClassBuild
{
    Bladesworn,   // Sword,  STR: heavy physical, crits, Flame imbue, Flame/Frost guards
    Spellblade,   // Sword,  INT: close-range Flame/Frost/Storm nukes, Frost Shield, Focus
    Warglaive,    // Glaive, STR: wide physical sweeps, Flame imbue, guards
    Lancecaller,  // Spear,  INT: long-reach nukes and area spells
    Marksman,     // Bow,    STR: physical arrows, Flame imbue
    Skyseer       // Bow,    INT: ranged nukes, Frost Shield, Storm magic power
}

public enum SkillKind { Attack, Buff, Passive }
public enum Element { Physical, Flame, Frost, Storm }       // Storm = the "lightning" element
public enum TargetMode { Single, AroundSelf, AroundTarget, Frontal }

// Stat changes given by a Buff (while it runs) or a Passive (always, when the weapon fits)
[Serializable]
public class SkillBonus
{
    public float physDamagePct;
    public float magicDamagePct;      // Storm skills mostly live here (magic attack power)
    public float physDefensePct;
    public float magicDefensePct;
    public float parryPct;            // "Focus" = parry ratio
    public float critPct;
    public float moveSpeedPct;
    public float imbueDamage;         // flat extra damage on every hit (STR builds: Flame imbue)
    public Element imbueElement = Element.Flame;
    public float shield;              // damage the Frost Shield can soak up

    public void AddScaled(SkillBonus o, float m)
    {
        physDamagePct += o.physDamagePct * m;
        magicDamagePct += o.magicDamagePct * m;
        physDefensePct += o.physDefensePct * m;
        magicDefensePct += o.magicDefensePct * m;
        parryPct += o.parryPct * m;
        critPct += o.critPct * m;
        moveSpeedPct += o.moveSpeedPct * m;
        imbueDamage += o.imbueDamage * m;
        shield += o.shield * m;
        if (o.imbueDamage > 0f) imbueElement = o.imbueElement;
    }
}

public static class ClassInfo
{
    public const string TraditionName = "Jade Dominion";

    public static string Name(ClassBuild b)
    {
        switch (b)
        {
            case ClassBuild.Bladesworn: return "Bladesworn";
            case ClassBuild.Spellblade: return "Spellblade";
            case ClassBuild.Warglaive: return "Warglaive";
            case ClassBuild.Lancecaller: return "Lancecaller";
            case ClassBuild.Marksman: return "Marksman";
            default: return "Skyseer";
        }
    }

    public static WeaponFamily Weapon(ClassBuild b)
    {
        if (b == ClassBuild.Bladesworn || b == ClassBuild.Spellblade) return WeaponFamily.Sword;
        if (b == ClassBuild.Warglaive || b == ClassBuild.Lancecaller) return WeaponFamily.Glaive;
        return WeaponFamily.Bow;
    }

    public static string WeaponName(ClassBuild b)
    {
        if (b == ClassBuild.Lancecaller) return "Spear";
        return Weapon(b).ToString();
    }

    public static bool IsStr(ClassBuild b)
    {
        return b == ClassBuild.Bladesworn || b == ClassBuild.Warglaive || b == ClassBuild.Marksman;
    }

    public static string Blurb(ClassBuild b)
    {
        switch (b)
        {
            case ClassBuild.Bladesworn: return "FULL STR. Sword fighter: big single hits and crits. Flame only as an imbue on the blade, Flame/Frost Guards for defence.";
            case ClassBuild.Spellblade: return "FULL INT. Sword mage: Flame, Frost and Storm nukes up close. Frost Shield for defence, Storm Surge for magic power, Focus for parry.";
            case ClassBuild.Warglaive: return "FULL STR. Glaive fighter: wide sweeping strikes against groups. Flame imbue plus Flame/Frost Guards.";
            case ClassBuild.Lancecaller: return "FULL INT. Spear caster: long-reach nukes and area spells. Frost Shield, Storm Surge and Focus.";
            case ClassBuild.Marksman: return "FULL STR. Bow archer: fast physical arrows from range. Flame imbue on the arrowheads, Guards for defence.";
            default: return "FULL INT. Bow mage: ranged Flame, Frost and Storm nukes. Frost Shield, Storm Surge and Focus.";
        }
    }

    public static Color Tint(ClassBuild b)
    {
        switch (b)
        {
            case ClassBuild.Bladesworn: return new Color(0.70f, 0.15f, 0.18f);
            case ClassBuild.Spellblade: return new Color(0.29f, 0.25f, 0.66f);
            case ClassBuild.Warglaive: return new Color(0.78f, 0.36f, 0.07f);
            case ClassBuild.Lancecaller: return new Color(0.10f, 0.55f, 0.55f);
            case ClassBuild.Marksman: return new Color(0.31f, 0.48f, 0.17f);
            default: return new Color(0.18f, 0.48f, 0.82f);
        }
    }

    public static Color ElementTint(Element e)
    {
        switch (e)
        {
            case Element.Flame: return new Color(1.0f, 0.45f, 0.10f);
            case Element.Frost: return new Color(0.45f, 0.85f, 1.0f);
            case Element.Storm: return new Color(0.75f, 0.55f, 1.0f);
            default: return new Color(0.75f, 0.78f, 0.85f);
        }
    }
}

[CreateAssetMenu(menuName = "MMO/Skill", fileName = "NewSkill")]
public class SkillData : ScriptableObject
{
    [Header("Identity")]
    public string skillName = "Skill";
    [TextArea] public string description;
    public ClassBuild[] classes;
    public WeaponFamily weapon = WeaponFamily.Any;
    public SkillKind kind;
    public Element element;
    public int requiredLevel = 1;
    public int maxSkillLevel = 10;

    [Header("Cost and timing")]
    public int mpCost = 5;
    public float cooldown = 5f;

    [Header("Attack")]
    public TargetMode target = TargetMode.Single;
    public float range = 3f;           // how far the target may be (Single / AroundTarget)
    public float radius = 4f;          // area size (Around*, Frontal)
    public int hits = 1;
    public float baseDamage = 20f;
    public float powerCoef = 1f;       // multiplies the attack bonus (physical) or magic power (elements)
    public float damagePerSkillLevel = 3f;
    public bool ignoreDefense;

    [Header("Attack: extra effects on enemies")]
    public float slowPercent;
    public float slowSeconds;
    public float stunSeconds;
    public float burnDamagePerSecond;
    public float burnSeconds;

    [Header("Buff / Passive")]
    public float duration = 60f;
    [Tooltip("Buffs with the same non-empty group replace each other (e.g. Imbue, Guard, Shield)")]
    public string exclusiveGroup;
    public SkillBonus bonus = new SkillBonus();

    public bool IsMagic { get { return element != Element.Physical; } }

    public bool UsableBy(ClassBuild b)
    {
        if (classes == null) return false;
        for (int i = 0; i < classes.Length; i++)
            if (classes[i] == b) return true;
        return false;
    }
}
