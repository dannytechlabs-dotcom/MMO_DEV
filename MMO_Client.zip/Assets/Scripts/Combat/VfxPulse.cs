using UnityEngine;

// Simple cast effects made from primitives (no art files needed).
public static class SkillVfx
{
    private static Material MakeMat(Color c)
    {
        Shader sh = Shader.Find("Sprites/Default");
        Material m = new Material(sh);
        m.color = c;
        return m;
    }

    private static GameObject Prim(PrimitiveType t, Color c)
    {
        GameObject go = GameObject.CreatePrimitive(t);
        go.layer = 2; // Ignore Raycast, so effects never block clicks
        Collider col = go.GetComponent<Collider>();
        if (col != null) Object.Destroy(col);
        go.GetComponent<Renderer>().material = MakeMat(c);
        return go;
    }

    // Expanding glowing sphere (area hits, impacts)
    public static void Burst(Vector3 pos, float radius, Color c)
    {
        GameObject go = Prim(PrimitiveType.Sphere, c);
        go.transform.position = pos + Vector3.up * 0.8f;
        VfxPulse p = go.AddComponent<VfxPulse>();
        p.Setup(0, 0.45f, c, 0.3f, radius * 2f, Vector3.zero, Vector3.zero);
    }

    // Flat ring on the ground (buffs, ground spells)
    public static void Ring(Vector3 pos, float radius, Color c)
    {
        GameObject go = Prim(PrimitiveType.Cylinder, c);
        go.transform.position = new Vector3(pos.x, pos.y + 0.05f, pos.z);
        VfxPulse p = go.AddComponent<VfxPulse>();
        p.Setup(1, 0.7f, c, 0.4f, radius * 2f, Vector3.zero, Vector3.zero);
    }

    // Small ball that flies from the caster to the target (arrows, bolts, javelins)
    public static void Bolt(Vector3 from, Vector3 to, Color c)
    {
        GameObject go = Prim(PrimitiveType.Sphere, c);
        go.transform.position = from;
        VfxPulse p = go.AddComponent<VfxPulse>();
        p.Setup(2, Mathf.Clamp(Vector3.Distance(from, to) / 40f, 0.08f, 0.35f), c, 0.25f, 0.25f, from, to);
    }
}

public class VfxPulse : MonoBehaviour
{
    private int mode;            // 0 sphere burst, 1 ground ring, 2 flying bolt
    private float life, born, startSize, endSize;
    private Color color;
    private Vector3 from, to;
    private Renderer rend;

    public void Setup(int mode, float life, Color color, float startSize, float endSize, Vector3 from, Vector3 to)
    {
        this.mode = mode; this.life = life; this.color = color;
        this.startSize = startSize; this.endSize = endSize; this.from = from; this.to = to;
        born = Time.time;
        rend = GetComponent<Renderer>();
        Apply(0f);
    }

    private void Update()
    {
        float t = (Time.time - born) / life;
        if (t >= 1f) { Destroy(gameObject); return; }
        Apply(t);
    }

    private void Apply(float t)
    {
        float size = Mathf.Lerp(startSize, endSize, t);
        float alpha = mode == 2 ? 1f : Mathf.Lerp(0.65f, 0f, t);
        if (rend != null) { Color c = color; c.a = alpha; rend.material.color = c; }

        if (mode == 1) transform.localScale = new Vector3(size, 0.02f, size);
        else transform.localScale = Vector3.one * size;

        if (mode == 2) transform.position = Vector3.Lerp(from, to, t);
    }
}
