using UnityEngine;
using UnityEngine.AI;

// Added to an enemy at runtime the first time a skill slows, stuns or burns it.
public class StatusEffects : MonoBehaviour
{
    private NavMeshAgent agent;
    private Health health;
    private Renderer[] renderers;
    private MaterialPropertyBlock block;
    private float baseSpeed;
    private float slowUntil, slowPct, stunUntil, burnUntil, burnDps, nextBurn;
    private bool tinted;

    public bool Stunned { get { return Time.time < stunUntil; } }

    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        health = GetComponent<Health>();
        renderers = GetComponentsInChildren<Renderer>();
        block = new MaterialPropertyBlock();
        if (agent != null) baseSpeed = agent.speed;
    }

    public void Slow(float percent, float seconds)
    {
        if (percent <= 0f || seconds <= 0f) return;
        slowPct = Mathf.Max(percent, Time.time < slowUntil ? slowPct : 0f);
        slowUntil = Mathf.Max(slowUntil, Time.time + seconds);
    }

    public void Stun(float seconds)
    {
        if (seconds <= 0f) return;
        stunUntil = Mathf.Max(stunUntil, Time.time + seconds);
    }

    public void Burn(float damagePerSecond, float seconds)
    {
        if (damagePerSecond <= 0f || seconds <= 0f) return;
        burnDps = Mathf.Max(damagePerSecond, Time.time < burnUntil ? burnDps : 0f);
        burnUntil = Mathf.Max(burnUntil, Time.time + seconds);
    }

    private void Update()
    {
        if (health != null && health.IsDead)
        {
            SetTint(false, Color.white);
            enabled = false;
            return;
        }

        if (agent != null)
        {
            float mult = Stunned ? 0f : (Time.time < slowUntil ? 1f - slowPct / 100f : 1f);
            agent.speed = baseSpeed * Mathf.Clamp01(mult);
            if (Stunned) agent.isStopped = true;
        }

        if (health != null && Time.time < burnUntil && Time.time >= nextBurn)
        {
            nextBurn = Time.time + 1f;
            health.TakeDamage(burnDps, true);
        }

        if (Stunned) SetTint(true, new Color(1f, 0.95f, 0.3f));
        else if (Time.time < burnUntil) SetTint(true, new Color(1f, 0.45f, 0.1f));
        else if (Time.time < slowUntil) SetTint(true, new Color(0.45f, 0.85f, 1f));
        else SetTint(false, Color.white);
    }

    private void SetTint(bool on, Color c)
    {
        if (!on && !tinted) return;
        tinted = on;
        foreach (Renderer r in renderers)
        {
            if (r == null) continue;
            if (on)
            {
                block.SetColor("_BaseColor", c);
                block.SetColor("_Color", c);
                r.SetPropertyBlock(block);
            }
            else r.SetPropertyBlock(null);
        }
    }
}
