using System;
using System.Collections.Generic;
using UnityEngine;

// Put on the Player (PlayerSkills adds it automatically if missing).
// Holds the chosen build and the list of skills that build can use.
// Skills are loaded from Assets/Resources/Skills (menu: MMO > Create Skills).
public class PlayerClass : MonoBehaviour
{
    [SerializeField] private ClassBuild build = ClassBuild.Bladesworn;
    [Tooltip("FULL STR / FULL INT: every stat point you earn goes into the build's main stat")]
    [SerializeField] private bool autoSpendStatPoints = true;
    [Tooltip("Off for now: there is no equip window yet. Turn on when weapons can be equipped (ItemData.weaponFamily).")]
    [SerializeField] private bool enforceWeapon = false;

    public event Action<ClassBuild> BuildChanged;

    private readonly List<SkillData> all = new List<SkillData>();
    private readonly List<SkillData> mine = new List<SkillData>();
    private PlayerStats stats;
    private Inventory inventory;

    public ClassBuild Build { get { return build; } }
    public WeaponFamily Weapon { get { return ClassInfo.Weapon(build); } }
    public bool IsStr { get { return ClassInfo.IsStr(build); } }
    public IReadOnlyList<SkillData> Skills { get { return mine; } }
    public int LoadedSkillCount { get { return all.Count; } }

    private void Awake()
    {
        stats = GetComponent<PlayerStats>();
        inventory = GetComponent<Inventory>();
        all.AddRange(Resources.LoadAll<SkillData>("Skills"));
        if (all.Count == 0)
            Debug.LogWarning("PlayerClass: no skills found. Run the menu MMO > Create Skills once.");
        Refresh();
    }

    private void Update()
    {
        if (autoSpendStatPoints && stats != null)
        {
            int guard = 0;
            while (stats.StatPoints > 0 && guard++ < 200)
                if (!stats.AddStatPoint(IsStr)) break;
        }
    }

    private void Refresh()
    {
        mine.Clear();
        foreach (SkillData s in all)
            if (s != null && s.UsableBy(build)) mine.Add(s);
        mine.Sort((a, b) =>
        {
            int c = a.requiredLevel.CompareTo(b.requiredLevel);
            return c != 0 ? c : a.kind.CompareTo(b.kind);
        });
    }

    public void SetBuild(ClassBuild b)
    {
        build = b;
        Refresh();
        if (BuildChanged != null) BuildChanged(b);
    }

    public bool IsLearned(SkillData s)
    {
        return stats == null || stats.Level >= s.requiredLevel;
    }

    public bool WeaponOk(SkillData s)
    {
        if (!enforceWeapon || s.weapon == WeaponFamily.Any) return true;
        if (inventory == null || inventory.Weapon == null || inventory.Weapon.data == null) return false;
        WeaponFamily f = inventory.Weapon.data.weaponFamily;
        return f == WeaponFamily.Any || f == s.weapon;
    }
}
