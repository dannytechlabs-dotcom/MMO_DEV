using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

// A real humanoid character built from primitives (no art files needed), with a weapon for the chosen build.
// Added to the Player automatically by PlayerSkills. It hides the old capsule body.
// Walk, attack, buff and sit animations are procedural. Press N to sit / stand.
// Assumes the Player object has scale 1,1,1.
public class ProceduralAvatar : MonoBehaviour
{
    [SerializeField] private bool hideOriginalBody = true;
    [SerializeField] private bool showNameTag = true;

    private PlayerClass cls;
    private PlayerSkills skills;
    private PlayerStats stats;
    private NavMeshAgent agent;

    private Transform root, torso, armL, armR, legL, legR, mountR, mountL;
    private readonly List<Renderer> glowParts = new List<Renderer>();
    private readonly List<Color> glowBase = new List<Color>();

    private bool isBow;
    private float armLRest, armRRest;
    private float phase, walkAmp, attackT = -1f, buffT = -1f, sitBlend;
    private bool sitting;
    private GUIStyle tagStyle;

    // =========================================================
    // SETUP
    // =========================================================

    private void Awake()
    {
        cls = GetComponent<PlayerClass>();
        skills = GetComponent<PlayerSkills>();
        stats = GetComponent<PlayerStats>();
        agent = GetComponent<NavMeshAgent>();
    }

    private void Start()
    {
        if (cls == null) cls = GetComponent<PlayerClass>();
        if (cls != null) cls.BuildChanged += OnBuildChanged;

        if (hideOriginalBody)
        {
            Renderer r = GetComponent<Renderer>();
            if (r != null) r.enabled = false;
        }
        Build();
    }

    private void OnDestroy()
    {
        if (cls != null) cls.BuildChanged -= OnBuildChanged;
    }

    private void OnBuildChanged(ClassBuild b) { Build(); }

    public void PlayAttack() { attackT = 0f; sitting = false; }
    public void PlayBuff() { buffT = 0f; }

    // =========================================================
    // BUILDING THE BODY
    // =========================================================

    private static Material MakeMat(Color c)
    {
        Shader sh = Shader.Find("Universal Render Pipeline/Lit");
        if (sh == null) sh = Shader.Find("Standard");
        if (sh == null) sh = Shader.Find("Sprites/Default");
        Material m = new Material(sh);
        m.color = c;
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", 0.25f);
        return m;
    }

    private Transform Part(Transform parent, string name, PrimitiveType type, Vector3 pos, Vector3 scale, Color color, Vector3 euler, bool glow)
    {
        GameObject go = GameObject.CreatePrimitive(type);
        go.name = name;
        Collider col = go.GetComponent<Collider>();
        if (col != null) DestroyImmediate(col);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        go.transform.localScale = scale;
        go.transform.localEulerAngles = euler;
        Renderer r = go.GetComponent<Renderer>();
        r.material = MakeMat(color);
        if (glow) { glowParts.Add(r); glowBase.Add(color); }
        return go.transform;
    }

    private Transform Part(Transform parent, string name, PrimitiveType type, Vector3 pos, Vector3 scale, Color color)
    {
        return Part(parent, name, type, pos, scale, color, Vector3.zero, false);
    }

    private Transform Pivot(Transform parent, string name, Vector3 pos)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        return go.transform;
    }

    private static Color Hex(string h)
    {
        Color c;
        return ColorUtility.TryParseHtmlString(h, out c) ? c : Color.magenta;
    }

    private static Color Dark(Color c, float f) { return new Color(c.r * f, c.g * f, c.b * f, 1f); }

    private void Build()
    {
        if (root != null) { root.gameObject.SetActive(false); Destroy(root.gameObject); }
        glowParts.Clear(); glowBase.Clear();

        ClassBuild b = cls != null ? cls.Build : ClassBuild.Bladesworn;
        bool str = ClassInfo.IsStr(b);
        isBow = ClassInfo.Weapon(b) == WeaponFamily.Bow;
        armLRest = isBow ? -75f : 0f;
        armRRest = isBow ? -25f : 0f;

        Color main = ClassInfo.Tint(b);
        Color skin = Hex("#E8B58C");
        Color metal = Hex("#B9BEC7");
        Color gold = Hex("#D9A93A");
        Color boot = Hex("#3B2A1E");
        Color hair = HairColor(b);

        CapsuleCollider cc = GetComponent<CapsuleCollider>();
        float feetY = cc != null ? cc.center.y - cc.height * 0.5f : -1f;

        GameObject rootGo = new GameObject("Avatar");
        root = rootGo.transform;
        root.SetParent(transform, false);
        root.localPosition = new Vector3(0f, feetY, 0f);

        // legs (pivot at the hip)
        legL = Pivot(root, "LegL", new Vector3(-0.12f, 0.9f, 0f));
        legR = Pivot(root, "LegR", new Vector3(0.12f, 0.9f, 0f));
        foreach (Transform leg in new[] { legL, legR })
        {
            Part(leg, "Leg", PrimitiveType.Capsule, new Vector3(0f, -0.42f, 0f), new Vector3(0.2f, 0.42f, 0.2f), Dark(main, 0.6f));
            Part(leg, "Boot", PrimitiveType.Cube, new Vector3(0f, -0.84f, 0.04f), new Vector3(0.22f, 0.12f, 0.32f), boot);
        }

        // torso (pivot at the waist)
        torso = Pivot(root, "Torso", new Vector3(0f, 0.9f, 0f));
        Part(torso, "Chest", PrimitiveType.Capsule, new Vector3(0f, 0.33f, 0f), new Vector3(0.46f, 0.33f, 0.26f), main);
        Part(torso, "Belt", PrimitiveType.Cylinder, new Vector3(0f, 0.02f, 0f), new Vector3(0.44f, 0.04f, 0.28f), gold);

        // head
        Transform head = Pivot(torso, "Head", new Vector3(0f, 0.78f, 0f));
        Part(head, "Skull", PrimitiveType.Sphere, new Vector3(0f, 0.15f, 0f), new Vector3(0.27f, 0.29f, 0.27f), skin);
        Part(head, "Hair", PrimitiveType.Sphere, new Vector3(0f, 0.2f, -0.02f), new Vector3(0.29f, 0.22f, 0.3f), hair);
        Part(head, "EyeL", PrimitiveType.Sphere, new Vector3(-0.055f, 0.16f, 0.12f), new Vector3(0.04f, 0.04f, 0.04f), Color.black);
        Part(head, "EyeR", PrimitiveType.Sphere, new Vector3(0.055f, 0.16f, 0.12f), new Vector3(0.04f, 0.04f, 0.04f), Color.black);

        // arms (pivot at the shoulder)
        armL = Pivot(torso, "ArmL", new Vector3(-0.31f, 0.62f, 0f));
        armR = Pivot(torso, "ArmR", new Vector3(0.31f, 0.62f, 0f));
        foreach (Transform arm in new[] { armL, armR })
        {
            Part(arm, "Sleeve", PrimitiveType.Capsule, new Vector3(0f, -0.28f, 0f), new Vector3(0.11f, 0.28f, 0.11f), Dark(main, 0.85f));
            Part(arm, "Hand", PrimitiveType.Sphere, new Vector3(0f, -0.58f, 0f), new Vector3(0.11f, 0.11f, 0.11f), skin);
        }
        mountR = Pivot(armR, "MountR", new Vector3(0f, -0.58f, 0f));
        mountL = Pivot(armL, "MountL", new Vector3(0f, -0.58f, 0f));

        // armour (STR) or robe (INT)
        if (str)
        {
            Part(torso, "PadL", PrimitiveType.Sphere, new Vector3(-0.29f, 0.66f, 0f), new Vector3(0.2f, 0.13f, 0.2f), metal);
            Part(torso, "PadR", PrimitiveType.Sphere, new Vector3(0.29f, 0.66f, 0f), new Vector3(0.2f, 0.13f, 0.2f), metal);
            Part(torso, "Plate", PrimitiveType.Cube, new Vector3(0f, 0.36f, 0.12f), new Vector3(0.3f, 0.3f, 0.04f), metal);
        }
        else
        {
            Part(root, "Robe", PrimitiveType.Cylinder, new Vector3(0f, 0.66f, 0f), new Vector3(0.5f, 0.22f, 0.36f), Dark(main, 0.75f));
            Color gem = ClassInfo.ElementTint(SignatureElement(b));
            Part(torso, "Gem", PrimitiveType.Sphere, new Vector3(0f, 0.45f, 0.13f), new Vector3(0.09f, 0.09f, 0.09f), gem, Vector3.zero, true);
        }

        // cape in the class colour
        Part(torso, "Cape", PrimitiveType.Cube, new Vector3(0f, 0.28f, -0.17f), new Vector3(0.42f, 0.78f, 0.03f), Dark(main, 0.7f));

        BuildWeapon(b);
    }

    private static Color HairColor(ClassBuild b)
    {
        switch (b)
        {
            case ClassBuild.Bladesworn: return Hex("#1A1A1F");
            case ClassBuild.Spellblade: return Hex("#C9CCD6");
            case ClassBuild.Warglaive: return Hex("#5A3B22");
            case ClassBuild.Lancecaller: return Hex("#14333A");
            case ClassBuild.Marksman: return Hex("#7A3B1E");
            default: return Hex("#E3C77A");
        }
    }

    private static Element SignatureElement(ClassBuild b)
    {
        if (b == ClassBuild.Spellblade) return Element.Storm;
        if (b == ClassBuild.Lancecaller) return Element.Frost;
        return Element.Flame;
    }

    private void BuildWeapon(ClassBuild b)
    {
        Color steel = Hex("#C9CED6");
        Color wood = Hex("#6B4A2B");
        Color gold = Hex("#D9A93A");
        Vector3 z = Vector3.zero;

        if (b == ClassBuild.Bladesworn || b == ClassBuild.Spellblade)
        {
            mountR.localEulerAngles = new Vector3(90f, 0f, 0f);
            bool thin = b == ClassBuild.Spellblade;
            Part(mountR, "Blade", PrimitiveType.Cube, new Vector3(0f, 0.55f, 0f), new Vector3(thin ? 0.05f : 0.08f, thin ? 0.85f : 0.95f, 0.02f), steel, z, true);
            Part(mountR, "Guard", PrimitiveType.Cube, new Vector3(0f, 0.08f, 0f), new Vector3(0.32f, 0.05f, 0.07f), gold);
            Part(mountR, "Hilt", PrimitiveType.Cylinder, new Vector3(0f, -0.06f, 0f), new Vector3(0.04f, 0.08f, 0.04f), wood);
            Part(mountR, "Pommel", PrimitiveType.Sphere, new Vector3(0f, -0.15f, 0f), new Vector3(0.07f, 0.07f, 0.07f), gold);
        }
        else if (b == ClassBuild.Warglaive)
        {
            mountR.localEulerAngles = new Vector3(70f, 0f, 0f);
            Part(mountR, "Pole", PrimitiveType.Cylinder, new Vector3(0f, 0.45f, 0f), new Vector3(0.035f, 0.95f, 0.035f), wood);
            Part(mountR, "Head", PrimitiveType.Cube, new Vector3(0f, 1.62f, 0f), new Vector3(0.13f, 0.55f, 0.02f), steel, z, true);
            Part(mountR, "Spur", PrimitiveType.Cube, new Vector3(0.08f, 1.42f, 0f), new Vector3(0.1f, 0.3f, 0.02f), steel, new Vector3(0f, 0f, -28f), true);
            Part(mountR, "Cap", PrimitiveType.Sphere, new Vector3(0f, 1.32f, 0f), new Vector3(0.07f, 0.07f, 0.07f), gold);
        }
        else if (b == ClassBuild.Lancecaller)
        {
            mountR.localEulerAngles = new Vector3(70f, 0f, 0f);
            Part(mountR, "Pole", PrimitiveType.Cylinder, new Vector3(0f, 0.45f, 0f), new Vector3(0.03f, 0.95f, 0.03f), wood);
            Part(mountR, "Tip", PrimitiveType.Cube, new Vector3(0f, 1.6f, 0f), new Vector3(0.09f, 0.32f, 0.02f), steel, z, true);
            Part(mountR, "Cross", PrimitiveType.Cube, new Vector3(0f, 1.4f, 0f), new Vector3(0.22f, 0.03f, 0.03f), gold);
            Part(mountR, "Tassel", PrimitiveType.Sphere, new Vector3(0f, 1.34f, 0f), new Vector3(0.08f, 0.08f, 0.08f), Hex("#B02030"));
        }
        else // bow, held in the left hand
        {
            mountL.localEulerAngles = new Vector3(75f, 0f, 0f);
            int segs = 8;
            Vector3 prev = Vector3.zero;
            for (int i = 0; i <= segs; i++)
            {
                float t = -1f + 2f * i / segs;
                Vector3 p = new Vector3(0f, t * 0.65f, 0.22f * (1f - t * t));
                if (i > 0)
                {
                    Vector3 mid = (p + prev) * 0.5f;
                    float len = Vector3.Distance(p, prev);
                    Transform seg = Part(mountL, "Limb", PrimitiveType.Cube, mid, new Vector3(0.03f, 0.03f, len + 0.01f), wood, z, i == 1 || i == segs);
                    seg.localRotation = Quaternion.LookRotation(p - prev);
                }
                prev = p;
            }
            Part(mountL, "String", PrimitiveType.Cube, new Vector3(0f, 0f, 0f), new Vector3(0.008f, 1.3f, 0.008f), Hex("#E8E0C8"));
            Part(mountL, "Grip", PrimitiveType.Cylinder, new Vector3(0f, 0f, 0.22f), new Vector3(0.05f, 0.1f, 0.05f), gold);
            // quiver on the back
            Part(torso, "Quiver", PrimitiveType.Cylinder, new Vector3(0.12f, 0.35f, -0.2f), new Vector3(0.1f, 0.28f, 0.1f), wood, new Vector3(0f, 0f, 18f), false);
            Part(torso, "Fletch", PrimitiveType.Cube, new Vector3(0.17f, 0.66f, -0.2f), new Vector3(0.08f, 0.1f, 0.02f), Hex("#C23B3B"));
        }
    }

    // =========================================================
    // ANIMATION
    // =========================================================

    private void Update()
    {
        if (root == null) return;

        if (!KeyBindings.TextInputActive && Input.GetKeyDown(KeyBindings.SitStand)) sitting = !sitting;

        float speed = agent != null ? agent.velocity.magnitude : 0f;
        if (sitting && speed > 0.3f) sitting = false;

        walkAmp = Mathf.Lerp(walkAmp, Mathf.Clamp01(speed / 3.5f), 10f * Time.deltaTime);
        phase += speed * Time.deltaTime * 2.4f;
        sitBlend = Mathf.MoveTowards(sitBlend, sitting ? 1f : 0f, 5f * Time.deltaTime);

        float swing = Mathf.Sin(phase) * walkAmp;
        float armScale = isBow ? 0.2f : 1f;
        float lLeg = swing * 35f, rLeg = -swing * 35f;
        float lArm = -swing * 25f * armScale + armLRest;
        float rArm = swing * 25f * armScale + armRRest;
        float twist = 0f;

        if (attackT >= 0f)
        {
            attackT += Time.deltaTime / 0.4f;
            float t = Mathf.Clamp01(attackT);
            if (isBow) rArm = Mathf.Lerp(-30f, -105f, Mathf.Sin(t * Mathf.PI));
            else
            {
                float e = 1f - (1f - t) * (1f - t);
                rArm = Mathf.Lerp(-130f, 55f, e);
                twist = Mathf.Lerp(25f, -25f, e);
            }
            if (attackT >= 1f) attackT = -1f;
        }

        if (buffT >= 0f)
        {
            buffT += Time.deltaTime / 0.7f;
            float raise = Mathf.Sin(Mathf.Clamp01(buffT) * Mathf.PI);
            lArm = Mathf.Lerp(lArm, -160f, raise);
            rArm = Mathf.Lerp(rArm, -160f, raise);
            if (buffT >= 1f) buffT = -1f;
        }

        // sitting: the body drops and the legs fold forward
        float bodyY = Mathf.Lerp(0.9f, 0.48f, sitBlend);
        torso.localPosition = new Vector3(0f, bodyY, 0f);
        legL.localPosition = new Vector3(-0.12f, bodyY, 0f);
        legR.localPosition = new Vector3(0.12f, bodyY, 0f);
        float fold = -85f * sitBlend;

        legL.localRotation = Quaternion.Euler(Mathf.Lerp(lLeg, fold, sitBlend), 0f, 0f);
        legR.localRotation = Quaternion.Euler(Mathf.Lerp(rLeg, fold, sitBlend), 0f, 0f);
        armL.localRotation = Quaternion.Euler(lArm, 0f, 0f);
        armR.localRotation = Quaternion.Euler(rArm, 0f, 0f);
        torso.localRotation = Quaternion.Euler(0f, twist, 0f);

        UpdateGlow();
    }

    // while an imbue runs, the weapon glows in the imbue element's colour
    private void UpdateGlow()
    {
        bool on = skills != null && skills.HasImbue;
        Color g = on ? ClassInfo.ElementTint(skills.ImbueElement) : Color.white;
        float k = on ? 0.65f + 0.35f * Mathf.Sin(Time.time * 6f) : 0f;
        for (int i = 0; i < glowParts.Count; i++)
        {
            if (glowParts[i] == null) continue;
            glowParts[i].material.color = k > 0f ? Color.Lerp(glowBase[i], g, k) : glowBase[i];
        }
    }

    // =========================================================
    // NAME TAG
    // =========================================================

    private void OnGUI()
    {
        if (!showNameTag || root == null) return;
        Camera cam = Camera.main;
        if (cam == null) return;
        Vector3 sp = cam.WorldToScreenPoint(root.position + Vector3.up * 2.15f);
        if (sp.z <= 0f) return;

        if (tagStyle == null)
            tagStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontSize = 12, fontStyle = FontStyle.Bold };

        string text = (cls != null ? ClassInfo.Name(cls.Build) : "Hero") + "  Lv " + (stats != null ? stats.Level : 1);
        Rect r = new Rect(sp.x - 100f, Screen.height - sp.y - 10f, 200f, 20f);
        GUI.color = Color.black;
        GUI.Label(new Rect(r.x + 1, r.y + 1, r.width, r.height), text, tagStyle);
        GUI.color = cls != null ? Color.Lerp(Color.white, ClassInfo.Tint(cls.Build), 0.5f) : Color.white;
        GUI.Label(r, text, tagStyle);
        GUI.color = Color.white;
    }
}
