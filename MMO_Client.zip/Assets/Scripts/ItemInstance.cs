using System;

// One entry in the bag or an equipment slot: an item definition plus its own state.
// (This file was EMPTY in every backup, which stops the whole project from compiling.)
[Serializable]
public class ItemInstance
{
    public ItemData data;
    public int level;                 // enhancement +0 .. +9
    public int count = 1;             // stack size
    public float secondsLeft = -1f;   // timed items: -1 = timer not started, 0 = expired

    // Older code writes both names, so they stay in sync
    public int quantity { get { return count; } set { count = value; } }

    public string Name { get { return data != null ? data.itemName : "(empty)"; } }

    public string Label
    {
        get
        {
            string text = Name;
            if (level > 0) text += " +" + level;
            if (count > 1) text += " x" + count;
            return text;
        }
    }

    public ItemInstance() { }

    public ItemInstance(ItemData data)
    {
        this.data = data;
    }
}
