using System;
using System.IO;
using System.Net;
using System.Text;
using UnityEngine;

// Talks to the AuthServer (plain HTTP on this PC). Unity never touches SQL Server directly.
// Same public methods as before, so LoginUI and PlayerDataPersistence keep working.
public class DatabaseManager : MonoBehaviour
{
    public static DatabaseManager Instance { get; private set; }

    [Header("Login server")]
    [SerializeField] private string serverUrl = "http://127.0.0.1:5000";

    private string token = "";
    public string AccountId { get; private set; } = "";

    [Serializable] private class AuthReq { public string username; public string password; }
    [Serializable] private class AuthResp { public bool ok; public string error; public string accountId; public string token; }
    [Serializable] private class SaveReq { public string username; public int gold; public int health; public string inventoryJson; public string equippedJson; }
    [Serializable] private class SaveResp { public bool ok; public string error; }
    [Serializable] private class LoadResp { public bool ok; public bool found; public string error; public int gold; public int health; public string inventoryJson; public string equippedJson; }

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
        Debug.Log("[Database] Using login server at " + serverUrl);
    }

    // Right-click the component header > Test Connection
    [ContextMenu("Test Connection")]
    public void TestConnection()
    {
        try
        {
            var req = (HttpWebRequest)WebRequest.Create(serverUrl.TrimEnd('/') + "/health");
            req.Timeout = 8000;
            using (var resp = (HttpWebResponse)req.GetResponse())
            using (var r = new StreamReader(resp.GetResponseStream()))
                Debug.Log("[Database] Server answered: " + r.ReadToEnd());
        }
        catch (Exception ex) { Debug.LogError("[Database] Cannot reach server (is AuthServer running?):\n" + ex.Message); }
    }

    private string Post(string path, string json, bool withToken)
    {
        var req = (HttpWebRequest)WebRequest.Create(serverUrl.TrimEnd('/') + path);
        req.Method = "POST";
        req.ContentType = "application/json";
        req.Timeout = 8000;
        req.ReadWriteTimeout = 8000;
        if (withToken && !string.IsNullOrEmpty(token)) req.Headers["Authorization"] = "Bearer " + token;

        byte[] body = Encoding.UTF8.GetBytes(json);
        req.ContentLength = body.Length;
        using (Stream s = req.GetRequestStream()) s.Write(body, 0, body.Length);

        try
        {
            using (var resp = (HttpWebResponse)req.GetResponse())
            using (var r = new StreamReader(resp.GetResponseStream()))
                return r.ReadToEnd();
        }
        catch (WebException ex) when (ex.Response != null)
        {
            using (var r = new StreamReader(ex.Response.GetResponseStream()))
                return r.ReadToEnd();   // server error body is JSON too
        }
    }

    // ---------------- LOGIN ----------------
    public bool LoginUser(string username, string password, out string userId)
    {
        userId = "";
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password)) return false;

        try
        {
            string json = Post("/login", JsonUtility.ToJson(new AuthReq { username = username.Trim(), password = password }), false);
            AuthResp resp = JsonUtility.FromJson<AuthResp>(json);
            if (resp == null || !resp.ok)
            {
                Debug.LogWarning("[Database] Login failed: " + (resp != null ? resp.error : json));
                return false;
            }
            token = resp.token;
            AccountId = resp.accountId;
            userId = resp.accountId;
            Debug.Log("[Database] Login successful: " + username + " (account " + userId + ")");
            return true;
        }
        catch (Exception ex)
        {
            Debug.LogError("[Database] LOGIN ERROR (is AuthServer running?):\n" + ex.Message);
            return false;
        }
    }

    // ---------------- REGISTER ----------------
    public bool RegisterUser(string username, string password, out string error)
    {
        error = "";
        if (string.IsNullOrWhiteSpace(username)) { error = "Username is required."; return false; }
        if (string.IsNullOrWhiteSpace(password)) { error = "Password is required."; return false; }

        try
        {
            string json = Post("/register", JsonUtility.ToJson(new AuthReq { username = username.Trim(), password = password }), false);
            AuthResp resp = JsonUtility.FromJson<AuthResp>(json);
            if (resp == null) { error = "Bad answer from server."; return false; }
            if (!resp.ok) { error = resp.error; return false; }
            Debug.Log("[Database] Account created: " + username);
            return true;
        }
        catch (Exception ex)
        {
            error = "Cannot reach login server. Is AuthServer running?";
            Debug.LogError("[Database] REGISTER ERROR:\n" + ex.Message);
            return false;
        }
    }

    // ---------------- SAVE / LOAD (uses the logged-in account, userId argument is ignored) ----------------
    public void SavePlayerData(string userId, string username, int gold, int health,
                               string inventoryJson, string equippedJson)
    {
        if (string.IsNullOrEmpty(token)) { Debug.LogWarning("[Database] Save skipped: not logged in."); return; }
        try
        {
            string json = Post("/player/save", JsonUtility.ToJson(new SaveReq
            {
                username = username, gold = gold, health = health,
                inventoryJson = inventoryJson, equippedJson = equippedJson
            }), true);
            SaveResp resp = JsonUtility.FromJson<SaveResp>(json);
            if (resp != null && resp.ok) Debug.Log("[Database] Player data saved: " + username);
            else Debug.LogError("[Database] SAVE ERROR: " + (resp != null ? resp.error : json));
        }
        catch (Exception ex) { Debug.LogError("[Database] SAVE ERROR:\n" + ex.Message); }
    }

    public bool TryLoadPlayerData(string userId, out int gold, out int health,
                                  out string inventoryJson, out string equippedJson)
    {
        gold = 0; health = 100; inventoryJson = ""; equippedJson = "";
        if (string.IsNullOrEmpty(token)) return false;
        try
        {
            string json = Post("/player/load", "{}", true);
            LoadResp resp = JsonUtility.FromJson<LoadResp>(json);
            if (resp == null || !resp.ok || !resp.found) return false;
            gold = resp.gold; health = resp.health;
            inventoryJson = resp.inventoryJson ?? ""; equippedJson = resp.equippedJson ?? "";
            return true;
        }
        catch (Exception ex) { Debug.LogError("[Database] LOAD ERROR:\n" + ex.Message); }
        return false;
    }
}
