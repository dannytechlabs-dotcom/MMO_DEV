using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using UnityEngine;

// Put this on the SAME object as the NetworkManager.
// It adds Unity Transport if it is missing and assigns it, so StartHost() works.
[DefaultExecutionOrder(-100)]
public class EnsureTransport : MonoBehaviour
{
    [SerializeField] private string address = "127.0.0.1";
    [SerializeField] private ushort port = 7777;

    private void Awake()
    {
        NetworkManager nm = GetComponent<NetworkManager>();
        if (nm == null)
        {
            Debug.LogError("EnsureTransport must be on the same object as the NetworkManager.");
            return;
        }

        UnityTransport transport = GetComponent<UnityTransport>();
        if (transport == null) transport = gameObject.AddComponent<UnityTransport>();

        if (nm.NetworkConfig.NetworkTransport == null)
            nm.NetworkConfig.NetworkTransport = transport;

        transport.SetConnectionData(address, port);
        Debug.Log($"[Network] Transport ready: {address}:{port}");
    }
}
