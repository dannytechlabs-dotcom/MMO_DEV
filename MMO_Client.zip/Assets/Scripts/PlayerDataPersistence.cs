using System;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;

[System.Serializable]
public class SerializableItem
{
    public string itemName;
    public int level;
    public int count;
    public float secondsLeft;
}

[System.Serializable]
public class InventorySaveData
{
    public List<SerializableItem> items = new List<SerializableItem>();
}

public class PlayerDataPersistence : NetworkBehaviour
{
    [Header("Settings")]
    [SerializeField] private bool autoSavePeriodically = true;
    [SerializeField] private float autoSaveIntervalSeconds = 300f;

    private Inventory inventory;
    private Health health;
    private PlayerStats stats;

    private float autoSaveTimer;

    private void Awake()
    {
        inventory = GetComponent<Inventory>();
        health = GetComponent<Health>();
        stats = GetComponent<PlayerStats>();
    }

    public override void OnNetworkSpawn()
    {
        if (IsServer)
        {
            string userId = OwnerClientId.ToString();
            LoadPlayerData(userId);
        }
    }

    public override void OnNetworkDespawn()
    {
        if (IsServer)
        {
            SavePlayerData();
        }
    }

    private void Update()
    {
        if (!IsServer || !autoSavePeriodically) return;

        autoSaveTimer += Time.deltaTime;
        if (autoSaveTimer >= autoSaveIntervalSeconds)
        {
            autoSaveTimer = 0f;
            SavePlayerData();
        }
    }

    public void SavePlayerData()
    {
        if (!IsServer || DatabaseManager.Instance == null) return;

        string userId = OwnerClientId.ToString();
        string username = $"Player_{OwnerClientId}";
        int gold = stats != null ? stats.Gold : 0;
       int currentHealth = health != null ? Mathf.RoundToInt(health.CurrentHealth) : 100;
        InventorySaveData bagData = new InventorySaveData();
        if (inventory != null)
        {
            foreach (var item in inventory.Bag)
            {
                if (item != null && item.data != null)
                {
                    bagData.items.Add(new SerializableItem
                    {
                        itemName = item.data.itemName,
                        level = item.level,
                        count = item.count,
                        secondsLeft = item.secondsLeft
                    });
                }
            }
        }
        string inventoryJson = JsonUtility.ToJson(bagData);

        DatabaseManager.Instance.SavePlayerData(userId, username, gold, currentHealth, inventoryJson, "{}");
    }

    private void LoadPlayerData(string userId)
    {
        if (!IsServer || DatabaseManager.Instance == null) return;

        if (DatabaseManager.Instance.TryLoadPlayerData(userId, out int gold, out int loadedHealth, out string inventoryJson, out string equippedJson))
        {
            if (stats != null) stats.AddGold(gold);
            if (health != null) health.SetHealthFromDatabase(loadedHealth);

            if (inventory != null && !string.IsNullOrEmpty(inventoryJson))
            {
                InventorySaveData bagData = JsonUtility.FromJson<InventorySaveData>(inventoryJson);
                if (bagData != null && bagData.items != null)
                {
                    foreach (var sItem in bagData.items)
                    {
                        ItemData data = inventory.FindItemDataByName(sItem.itemName);
                        if (data != null)
                        {
                            inventory.TryAdd(data, sItem.count);
                        }
                    }
                }
            }
            Debug.Log($"[Persistence] Date încărcate pentru clientul {OwnerClientId}.");
        }
    }
}