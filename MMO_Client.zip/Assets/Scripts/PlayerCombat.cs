using UnityEngine;

// Your original auto-attack: left double-click (or Ctrl+click) a monster and the player attacks it.
// Now also adds the Flame imbue (STR builds), shows a damage number and swings the avatar's weapon.
// No network code here. Needs PlayerController and PlayerStats on the same object.
[RequireComponent(typeof(PlayerController))]
public class PlayerCombat : MonoBehaviour
{
    [SerializeField] private int damage = 10;
    [SerializeField] private float attackRange = 2.5f;
    [SerializeField] private float attackCooldown = 1f;

    private PlayerController controller;
    private PlayerStats stats;
    private PlayerSkills skills;
    private float nextAttackTime;

    private void Awake()
    {
        controller = GetComponent<PlayerController>();
        stats = GetComponent<PlayerStats>();
        skills = GetComponent<PlayerSkills>();
    }

    private void Update()
    {
        if (SafeZone.IsSafe(transform.position)) return; // no fighting in town

        Transform target = controller.CurrentTarget;
        if (target == null) return;
        if (!controller.IsAttacking) return; // selected only: wait for double-click

        Health targetHealth = target.GetComponent<Health>();
        if (targetHealth == null || targetHealth.IsDead) return;

        float distance = Vector3.Distance(transform.position, target.position);
        if (distance > attackRange) return;

        if (Time.time >= nextAttackTime)
        {
            nextAttackTime = Time.time + attackCooldown;
            float mult = stats != null ? stats.PhysMult : 1f;   // Angelic Spirit + VIP + skill damage bonus
            int total = Mathf.RoundToInt((damage + (stats != null ? stats.DamageBonus : 0)) * mult);
            if (skills != null) total += Mathf.RoundToInt(skills.ImbueDamage);   // Flame imbue

            float before = targetHealth.Current;
            targetHealth.TakeDamage(total, stats != null && stats.IgnoreDefense);
            if (skills != null) skills.NotifyBasicHit(targetHealth, before - targetHealth.Current);
        }
    }
}
