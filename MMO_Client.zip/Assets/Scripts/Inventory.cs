using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    [Header("Inventory")]
    [SerializeField] private int maxSlots = 30;

    [SerializeField]
    private List<ItemInstance> bag = new List<ItemInstance>();

    [Header("Equipment")]
    [SerializeField] private ItemInstance weapon;
    [SerializeField] private ItemInstance armor;
    [SerializeField] private ItemInstance helmet;
    [SerializeField] private ItemInstance accessory;

    private PlayerStats stats;

    public IReadOnlyList<ItemInstance> Bag => bag;

    public ItemInstance Weapon => weapon;
    public ItemInstance Armor => armor;
    public ItemInstance Helmet => helmet;
    public ItemInstance Accessory => accessory;

    // Angelic Spirit equipped in the Spirit slot.
    public ItemInstance Spirit
    {
        get
        {
            foreach (ItemInstance item in bag)
            {
                if (item == null || item.data == null)
                    continue;

                if (item.data.type == ItemType.AngelicSpirit)
                    return item;
            }

            return null;
        }
    }

    // Total weapon damage from equipped weapon.
    public int WeaponDamage
    {
        get
        {
            if (weapon == null || weapon.data == null)
                return 0;

            return weapon.data.damageBonus;
        }
    }

    // Total armor HP from equipped armor.
    public int ArmorHealth
    {
        get
        {
            if (armor == null || armor.data == null)
                return 0;

            return armor.data.healthBonus;
        }
    }

    private void Awake()
    {
        stats = GetComponent<PlayerStats>();
    }

    // =========================================================
    // ADD
    // =========================================================

    // Compatibility method used by EnemyLoot.
    public bool Add(ItemData item)
    {
        return TryAdd(item, 1);
    }

    public bool Add(ItemData item, int amount)
    {
        return TryAdd(item, amount);
    }

    public bool TryAdd(ItemData item, int amount = 1)
    {
        if (item == null || amount <= 0)
            return false;

        int remaining = amount;

        // First try existing stacks.
        for (int i = 0; i < bag.Count && remaining > 0; i++)
        {
            ItemInstance slot = bag[i];

            if (slot == null || slot.data == null)
                continue;

            if (slot.data != item)
                continue;

            if (!item.CanStack)
                continue;

            int current = slot.count;
            int limit = item.StackLimit;
            int space = Mathf.Max(0, limit - current);

            if (space <= 0)
                continue;

            int addAmount = Mathf.Min(space, remaining);

            slot.count += addAmount;
            slot.quantity = slot.count;

            remaining -= addAmount;
        }

        // Create new slots for anything remaining.
        while (remaining > 0)
        {
            if (bag.Count >= maxSlots)
                return false;

            int addAmount = item.CanStack
                ? Mathf.Min(remaining, item.StackLimit)
                : 1;

            ItemInstance instance = new ItemInstance(item);

            instance.count = addAmount;
            instance.quantity = addAmount;

            bag.Add(instance);

            remaining -= addAmount;
        }

        return true;
    }

    // =========================================================
    // CAN ADD
    // =========================================================

    public bool CanAdd(ItemData item, int amount = 1)
    {
        if (item == null || amount <= 0)
            return false;

        int remaining = amount;

        // Check existing stack space.
        if (item.CanStack)
        {
            foreach (ItemInstance slot in bag)
            {
                if (slot == null || slot.data == null)
                    continue;

                if (slot.data != item)
                    continue;

                int space = Mathf.Max(
                    0,
                    item.StackLimit - slot.count
                );

                remaining -= space;

                if (remaining <= 0)
                    return true;
            }
        }

        // Check free slots.
        int requiredSlots;

        if (item.CanStack)
            requiredSlots = Mathf.CeilToInt(
                remaining / (float)item.StackLimit
            );
        else
            requiredSlots = remaining;

        return bag.Count + requiredSlots <= maxSlots;
    }

    // =========================================================
    // REMOVE ONE
    // =========================================================

    private void RemoveOne(ItemInstance item)
    {
        if (item == null)
            return;

        item.count--;
        item.quantity = item.count;

        if (item.count <= 0)
            bag.Remove(item);
    }

    // =========================================================
    // CONSUME BY NAME
    // =========================================================

    public bool ConsumeOne(string itemName)
    {
        if (string.IsNullOrEmpty(itemName))
            return false;

        for (int i = 0; i < bag.Count; i++)
        {
            ItemInstance item = bag[i];

            if (item == null || item.data == null)
                continue;

            if (item.Name == itemName ||
                item.data.itemName == itemName)
            {
                RemoveOne(item);
                return true;
            }
        }

        return false;
    }

    // =========================================================
    // CONSUME BY ITEM TYPE
    // =========================================================

    public bool ConsumeOne(ItemType itemType)
    {
        for (int i = 0; i < bag.Count; i++)
        {
            ItemInstance item = bag[i];

            if (item == null || item.data == null)
                continue;

            if (item.data.type != itemType)
                continue;

            RemoveOne(item);
            return true;
        }

        return false;
    }

    // =========================================================
    // COUNT BY NAME
    // =========================================================

    public int CountOf(string itemName)
    {
        if (string.IsNullOrEmpty(itemName))
            return 0;

        int total = 0;

        foreach (ItemInstance item in bag)
        {
            if (item == null || item.data == null)
                continue;

            if (item.Name == itemName ||
                item.data.itemName == itemName)
            {
                total += item.count;
            }
        }

        return total;
    }

    // =========================================================
    // COUNT BY ITEM TYPE
    // =========================================================

    public int CountOf(ItemType itemType)
    {
        int total = 0;

        foreach (ItemInstance item in bag)
        {
            if (item == null || item.data == null)
                continue;

            if (item.data.type == itemType)
                total += item.count;
        }

        return total;
    }

    // =========================================================
    // BUY
    // =========================================================

    public bool TryBuy(
        ItemData item,
        int quantity,
        out string message)
    {
        message = "";

        if (item == null)
        {
            message = "Invalid item.";
            return false;
        }

        if (quantity <= 0)
        {
            message = "Invalid quantity.";
            return false;
        }

        if (stats == null)
            stats = GetComponent<PlayerStats>();

        if (stats == null)
        {
            message = "Player stats not found.";
            return false;
        }

        int totalCost = item.buyPrice * quantity;

        if (stats.Gold < totalCost)
        {
            message = "Not enough gold.";
            return false;
        }

        if (!CanAdd(item, quantity))
        {
            message = "Inventory is full.";
            return false;
        }

        if (!stats.SpendGold(totalCost))
        {
            message = "Could not spend gold.";
            return false;
        }

        if (!TryAdd(item, quantity))
        {
            stats.AddGold(totalCost);

            message = "Could not add item.";
            return false;
        }

        message = $"Bought {quantity}x {item.itemName}.";
        return true;
    }

    public bool TryBuy(ItemData item, int quantity = 1)
    {
        string message;

        return TryBuy(
            item,
            quantity,
            out message
        );
    }

    // =========================================================
    // SELL
    // =========================================================

    public bool TrySell(
        ItemInstance item,
        out string message)
    {
        message = "";

        if (item == null || item.data == null)
        {
            message = "Invalid item.";
            return false;
        }

        if (!bag.Contains(item))
        {
            message = "Item is not in your inventory.";
            return false;
        }

        int sellPrice = item.data.sellPrice;

        RemoveOne(item);

        if (stats == null)
            stats = GetComponent<PlayerStats>();

        if (stats != null)
            stats.AddGold(sellPrice);

        message =
            $"Sold {item.Name} for {sellPrice} gold.";

        return true;
    }

    public bool TrySell(int bagIndex)
    {
        if (bagIndex < 0 || bagIndex >= bag.Count)
            return false;

        ItemInstance item = bag[bagIndex];

        string message;

        return TrySell(
            item,
            out message
        );
    }

    // =========================================================
    // FIND ITEM
    // =========================================================

    public ItemData FindItemDataByName(string itemName)
    {
        if (string.IsNullOrEmpty(itemName))
            return null;

        foreach (ItemInstance item in bag)
        {
            if (item == null || item.data == null)
                continue;

            if (item.data.itemName == itemName)
                return item.data;
        }

        return null;
    }
}