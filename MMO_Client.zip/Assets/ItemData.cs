using UnityEngine;

// New types are added at the END so existing item assets keep their type
public enum ItemType { Weapon, Armor, Potion, Accessory, Avatar, AngelicSpirit, VipBuff, SpiritScroll, ReturnScroll, ReverseReturnScroll, ResurrectionScroll }

// Items handed to the player together with another item (for example the VIP Buff gift scrolls)
[System.Serializable]
public class ItemGrant
{
    public ItemData item;
    public int count = 1;
}

[CreateAssetMenu(menuName = "MMO/Item", fileName = "NewItem")]
public class ItemData : ScriptableObject
{
    public string itemName = "Item";
    public ItemType type;

    [Header("Shop")]
    public int buyPrice = 50;   // what the shop charges you
    public int sellPrice = 15;  // what the shop pays you (usually 20-40% of buy)

    [Header("Stacking (potions always stack)")]
    public bool stackable;
    public int maxStack = 20;

    [Header("Weapon")]
    public int damageBonus;
    public WeaponFamily weaponFamily;   // Sword / Glaive (glaive + spear) / Bow. Any = fits every build.

    [Header("Armor")]
    public int healthBonus;

    [Header("Potion")]
    public int healAmount = 50;

    [Header("Angelic Spirit / VIP Buff / Reactivation Scroll")]
    public int durationDays = 30;          // buff length (Spirit timer, VIP, or what a scroll restores)
    public float percentDamage;            // physical AND magic damage increase (%)
    public float percentAbsorb;            // physical AND magic damage absorption (%)
    public float percentPerEnhance = 1f;   // Spirit only: extra % per enhancement level, on damage and absorb
    public float percentMoveSpeed;         // Spirit only: movement speed (%)
    public float percentExp;               // VIP only: extra EXP (%)
    public float enhanceSuccessBonus;      // VIP only: extra enhancement success chance (percentage points)
    public int statBonus;                  // VIP only: flat bonus to STR and INT

    [Header("VIP Buff gifts (given when the VIP Buff is activated)")]
    public ItemGrant[] grants;

    // Consumables always stack
    public bool IsConsumable => type == ItemType.Potion || type == ItemType.VipBuff || type == ItemType.SpiritScroll
        || type == ItemType.ReturnScroll || type == ItemType.ReverseReturnScroll || type == ItemType.ResurrectionScroll;

    public bool CanStack => stackable || IsConsumable;
    public int StackLimit => CanStack ? Mathf.Max(1, maxStack) : 1;
}
