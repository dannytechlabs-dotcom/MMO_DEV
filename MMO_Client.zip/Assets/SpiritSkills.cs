using UnityEngine;

// Put on the Player. The two Angelic Spirit skills. They only work while an Angelic Spirit
// is equipped and not expired. Temporary keys: 4 and 5 (see KeyBindings).
//  Skill 1 - Divine Omnipotence: timed buff, more physical + magic damage and movement speed.
//            Stronger if a VIP Buff is active.
//  Skill 2 - Ignore Monster Defence: your hits skip the monster's defence for a while.
public class SpiritSkills : MonoBehaviour
{
    [Header("Skill 1 - Divine Omnipotence (key 4)")]
    [SerializeField] private float divineDuration = 600f;   // 10 minutes
    [SerializeField] private float divineCooldown = 900f;
    [SerializeField] private float divineDamage = 10f;      // % physical and magic damage
    [SerializeField] private float divineDamageVip = 35f;   // same, with a VIP Buff active
    [SerializeField] private float divineMove = 10f;        // % movement speed
    [SerializeField] private float divineMoveVip = 25f;

    [Header("Skill 2 - Ignore Monster Defence (key 5)")]
    [SerializeField] private float ignoreDuration = 30f;
    [SerializeField] private float ignoreCooldown = 120f;

    private PlayerBuffs buffs;
    private Health health;
    private float divineEnd, divineReady;
    private float ignoreEnd, ignoreReady;
    private string message = "";
    private float messageUntil;

    private bool Vip => buffs != null && buffs.VipActive;
    public float DivineSecondsLeft => Mathf.Max(0f, divineEnd - Time.time);
    public float IgnoreSecondsLeft => Mathf.Max(0f, ignoreEnd - Time.time);
    public float DivineDamagePercent => DivineSecondsLeft > 0f ? (Vip ? divineDamageVip : divineDamage) : 0f;
    public float DivineMovePercent => DivineSecondsLeft > 0f ? (Vip ? divineMoveVip : divineMove) : 0f;
    public bool IgnoringDefense => IgnoreSecondsLeft > 0f;

    private void Awake()
    {
        buffs = GetComponent<PlayerBuffs>();
        health = GetComponent<Health>();
    }

    private void Update()
    {
        if (KeyBindings.TextInputActive) return;
        if (health != null && health.IsDead) return;

        if (Input.GetKeyDown(KeyBindings.SpiritSkill1)) CastDivine();
        if (Input.GetKeyDown(KeyBindings.SpiritSkill2)) CastIgnore();
    }

    private bool CanCast()
    {
        if (buffs != null && buffs.SpiritActive) return true;
        Say("You need an active Angelic Spirit equipped.");
        return false;
    }

    private void CastDivine()
    {
        if (!CanCast()) return;
        if (Time.time < divineReady) { Say($"Divine Omnipotence cooldown: {divineReady - Time.time:0}s"); return; }

        divineEnd = Time.time + divineDuration;
        divineReady = Time.time + divineCooldown;
        Say("Divine Omnipotence!");
    }

    private void CastIgnore()
    {
        if (!CanCast()) return;
        if (Time.time < ignoreReady) { Say($"Ignore Defence cooldown: {ignoreReady - Time.time:0}s"); return; }

        ignoreEnd = Time.time + ignoreDuration;
        ignoreReady = Time.time + ignoreCooldown;
        Say("Ignore Monster Defence!");
    }

    private void Say(string text)
    {
        message = text;
        messageUntil = Time.time + 3f;
    }

    private void OnGUI()
    {
        bool usable = buffs != null && buffs.SpiritActive;
        DrawSlot(2, "F5", "Divine", divineEnd, divineReady, usable);
        DrawSlot(3, "F6", "Ignore", ignoreEnd, ignoreReady, usable);

        if (Time.time < messageUntil)
            GUI.Label(new Rect(Screen.width / 2f - 150f, Screen.height - 120f, 400f, 24f), message);
    }

    // Same layout as the Strike / Wave slots in PlayerSkills (slots 3 and 4 of the bar)
    private void DrawSlot(int index, string key, string label, float endTime, float readyTime, bool usable)
    {
        float size = 64f;
        float x = Screen.width / 2f - size - 4f + index * (size + 8f);
        float y = Screen.height - size - 110f;   // above the skill hotbar

        float active = Mathf.Max(0f, endTime - Time.time);
        float cooldown = Mathf.Max(0f, readyTime - Time.time);

        Color color;
        string state;
        if (active > 0f) { color = new Color(0.7f, 0.55f, 0.1f); state = $"ON {(int)(active / 60f)}:{(int)(active % 60f):00}"; }
        else if (cooldown > 0f) { color = new Color(0.3f, 0.3f, 0.3f); state = $"{cooldown:0}s"; }
        else if (!usable) { color = new Color(0.35f, 0.15f, 0.15f); state = "No spirit"; }
        else { color = new Color(0.15f, 0.3f, 0.6f); state = "Ready"; }

        GUI.color = color;
        GUI.DrawTexture(new Rect(x, y, size, size), Texture2D.whiteTexture);
        GUI.color = Color.white;
        GUI.Label(new Rect(x + 6, y + 4, size, size), $"{key}\n{label}\n{state}");
    }
}
