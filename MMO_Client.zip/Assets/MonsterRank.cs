using UnityEngine;

// Added to a monster by EnemySpawner (you do not add it by hand).
// Turns a normal monster into a stronger rank: more HP, damage, defence, size and rewards.
public class MonsterRank : MonoBehaviour
{
    public enum Rank { General, Champion, Giant, Titan, Unique }

    public Rank CurrentRank { get; private set; } = Rank.General;

    public void Apply(Rank rank)
    {
        CurrentRank = rank;
        if (rank == Rank.General) return;

        float hpMult, dmgMult, rewardMult, scale;
        int extraDefense;
        Color color;

        switch (rank)
        {
            case Rank.Champion: hpMult = 2f;  dmgMult = 1.3f; rewardMult = 2f;  scale = 1.15f; extraDefense = 0;  color = new Color(1f, 0.7f, 0.2f); break;
            case Rank.Giant:    hpMult = 5f;  dmgMult = 1.8f; rewardMult = 5f;  scale = 1.5f;  extraDefense = 10; color = new Color(0.4f, 0.7f, 1f); break;
            case Rank.Titan:    hpMult = 12f; dmgMult = 2.5f; rewardMult = 12f; scale = 2f;    extraDefense = 20; color = new Color(0.8f, 0.4f, 1f); break;
            default:            hpMult = 40f; dmgMult = 4f;   rewardMult = 40f; scale = 2.5f;  extraDefense = 30; color = new Color(1f, 0.25f, 0.25f); break; // Unique
        }

        Health health = GetComponent<Health>();
        if (health != null)
        {
            health.SetMaxHealth(Mathf.RoundToInt(health.Max * hpMult), true);
            health.SetDefensePercent(health.DefensePercent + extraDefense);
        }

        EnemyAI ai = GetComponent<EnemyAI>();
        if (ai != null) ai.DamageMultiplier = dmgMult;

        EnemyReward reward = GetComponent<EnemyReward>();
        if (reward != null) reward.RewardMultiplier = rewardMult;

        transform.localScale *= scale;

        HealthBarGUI bar = GetComponent<HealthBarGUI>();
        if (bar != null) bar.SetRank(rank.ToString(), color);
    }
}
