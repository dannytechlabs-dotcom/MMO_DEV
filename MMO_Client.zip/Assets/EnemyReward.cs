using UnityEngine;

[RequireComponent(typeof(Health))]
public class EnemyReward : MonoBehaviour
{
    [SerializeField] private int xpReward = 30;
    [SerializeField] private int goldReward = 1000;   // TEST VALUE (was 10)

    // Set by MonsterRank (Champion 2x, Giant 5x, Titan 12x, Unique 40x)
    public float RewardMultiplier = 1f;

    private Health health;

    private void Awake()
    {
        health = GetComponent<Health>();
    }

    private void OnEnable()
    {
        health.OnDied += GiveReward;
    }

    private void OnDisable()
    {
        health.OnDied -= GiveReward;
    }

    private void GiveReward()
    {
        PlayerStats stats = FindAnyObjectByType<PlayerStats>();
        if (stats != null)
        {
            stats.AddXp(Mathf.RoundToInt(xpReward * RewardMultiplier));
            stats.AddGold(Mathf.RoundToInt(goldReward * RewardMultiplier));
        }
    }
}
