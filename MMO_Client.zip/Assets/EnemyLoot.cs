using UnityEngine;

[RequireComponent(typeof(Health))]
public class EnemyLoot : MonoBehaviour
{
    [SerializeField] private ItemData[] possibleDrops;
    [SerializeField, Range(0f, 1f)] private float dropChance = 0.5f;

    private Health health;

    private void Awake()
    {
        health = GetComponent<Health>();
    }

    private void OnEnable()
    {
        health.OnDied += Drop;
    }

    private void OnDisable()
    {
        health.OnDied -= Drop;
    }

    private void Drop()
    {
        if (possibleDrops == null || possibleDrops.Length == 0) return;
        if (Random.value > dropChance) return;

         Inventory inv = FindAnyObjectByType<Inventory>();
        if (inv == null) return;

        ItemData item = possibleDrops[Random.Range(0, possibleDrops.Length)];
        if (item != null) inv.Add(item);
    }
}
