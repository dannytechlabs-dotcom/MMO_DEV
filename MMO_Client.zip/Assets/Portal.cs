using UnityEngine;
using UnityEngine.AI;

// Walk into the portal to be teleported to the destination Transform (same scene).
public class Portal : MonoBehaviour
{
    [SerializeField] private string portalName = "Portal";
    [SerializeField] private Transform destination;
    [SerializeField] private float triggerRadius = 1.5f;
    [SerializeField] private int minLevel = 1;

    private static float nextTeleportTime;
    private static GUIStyle tagStyle;
    private static GUIStyle warnStyle;

    private PlayerController player;
    private string warning = "";
    private float warningUntil;

    private void Update()
    {
        if (destination == null || Time.time < nextTeleportTime) return;

        if (player == null)
        {
            player = FindAnyObjectByType<PlayerController>();
            if (player == null) return;
        }

        if (!player.enabled) return; // dead players can't use portals

        Vector3 d = player.transform.position - transform.position;
        d.y = 0f;
        if (d.magnitude > triggerRadius) return;

        Teleport();
    }

    private void Teleport()
    {
        PlayerStats stats = player.GetComponent<PlayerStats>();
        if (stats != null && stats.Level < minLevel)
        {
            warning = $"You need level {minLevel} to use this portal.";
            warningUntil = Time.time + 2f;
            return;
        }

        player.ClearTargets();

        NavMeshAgent agent = player.GetComponent<NavMeshAgent>();
        if (agent != null)
        {
            agent.ResetPath();
            agent.Warp(destination.position);
        }
        else
        {
            player.transform.position = destination.position;
        }

        nextTeleportTime = Time.time + 1.5f; // stops instant ping-pong between portals
    }

    private void OnGUI()
    {
        Camera cam = Camera.main;
        if (cam == null) return;

        if (tagStyle == null)
        {
            tagStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold };
            tagStyle.normal.textColor = Color.cyan;

            warnStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold, fontSize = 16 };
            warnStyle.normal.textColor = Color.red;
        }

        Vector3 screen = cam.WorldToScreenPoint(transform.position + Vector3.up * 2f);
        if (screen.z > 0f)
        {
            string label = minLevel > 1 ? $"{portalName} (Lv {minLevel}+)" : portalName;
            GUI.Label(new Rect(screen.x - 100f, Screen.height - screen.y - 10f, 200f, 20f), label, tagStyle);
        }

        if (Time.time < warningUntil)
            GUI.Label(new Rect(Screen.width / 2f - 200f, Screen.height / 2f - 100f, 400f, 30f), warning, warnStyle);
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, triggerRadius);

        if (destination != null)
            Gizmos.DrawLine(transform.position, destination.position);
    }
}
