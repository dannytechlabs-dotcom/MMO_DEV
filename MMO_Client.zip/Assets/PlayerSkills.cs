using System.Collections.Generic;
using UnityEngine;

// Skill system for the Player: hotbar (10 slots x 4 pages), casting, buffs, passives, skill book.
//   Keys 1..0 cast the slot, F1..F4 change page, S opens the skill book, X or mouse wheel click = basic skill.
//   Left click a slot = cast. Right click a slot = clear it.
// Needs: PlayerController + PlayerStats on the same object. PlayerClass and ProceduralAvatar are added automatically.
[RequireComponent(typeof(PlayerController))]
public class PlayerSkills : MonoBehaviour
{
    [Header("Targets (keep the value you already had)")]
    [SerializeField] private LayerMask enemyMask;

    [Header("Tuning")]
    [SerializeField] private float critMultiplier = 1.6f;
    [SerializeField] private float globalCooldown = 0.4f;
    [Tooltip("Shows test buttons in the skill book (switch build, +1 level). Turn off before real players join.")]
    [SerializeField] private bool devTools = true;

    private class ActiveBuff { public SkillData skill; public float end; public int level; public float shield; }
    private class Popup { public Vector3 pos; public string text; public Color color; public float born; public bool big; }

    private PlayerController controller;
    private PlayerStats stats;
    private PlayerClass cls;
    private ProceduralAvatar avatar;

    private readonly List<ActiveBuff> buffs = new List<ActiveBuff>();
    private readonly Dictionary<SkillData, float> readyAt = new Dictionary<SkillData, float>();
    private readonly Dictionary<SkillData, int> skillLevels = new Dictionary<SkillData, int>();
    private readonly List<Popup> popups = new List<Popup>();
    private readonly SkillData[,] bar = new SkillData[4, 10];
    private SkillBonus total = new SkillBonus();

    private int page;
    private float globalReady;
    private bool bookOpen;
    private Vector2 bookScroll;
    private string message = "";
    private float messageUntil;

    // changes asked for during OnGUI are applied in Update (keeps the GUI layout stable)
    private bool hasPendingBuild; private ClassBuild pendingBuild;
    private bool pendingLevelUp;
    private SkillData pendingAssign;

    private GUIStyle small, centered, popupStyle, wrap;

    // ---- read by PlayerStats, PlayerBuffs, PlayerCombat, ProceduralAvatar ----
    public float PhysDamagePct { get { return total.physDamagePct; } }
    public float MagicDamagePct { get { return total.magicDamagePct; } }
    public float PhysDefensePct { get { return total.physDefensePct; } }
    public float MagicDefensePct { get { return total.magicDefensePct; } }
    public float ParryPct { get { return total.parryPct; } }
    public float CritPct { get { return total.critPct; } }
    public float MoveSpeedPct { get { return total.moveSpeedPct; } }
    public float ImbueDamage { get { return total.imbueDamage; } }
    public bool HasImbue { get { return total.imbueDamage > 0f; } }
    public Element ImbueElement { get { return total.imbueElement; } }
    public PlayerClass Class { get { return cls; } }

    // =========================================================
    // SETUP
    // =========================================================

    private void Awake()
    {
        controller = GetComponent<PlayerController>();
        stats = GetComponent<PlayerStats>();

        cls = GetComponent<PlayerClass>();
        if (cls == null) cls = gameObject.AddComponent<PlayerClass>();

        avatar = GetComponent<ProceduralAvatar>();
        if (avatar == null) avatar = gameObject.AddComponent<ProceduralAvatar>();

        if (enemyMask.value == 0) enemyMask = LayerMask.GetMask("Enemy");
        cls.BuildChanged += OnBuildChanged;
    }

    private void Start()
    {
        FillDefaultBar();
    }

    private void OnDestroy()
    {
        if (cls != null) cls.BuildChanged -= OnBuildChanged;
    }

    private void OnBuildChanged(ClassBuild b)
    {
        buffs.Clear();
        readyAt.Clear();
        page = 0;
        FillDefaultBar();
        Say("Build changed to " + ClassInfo.Name(b));
    }

    // every attack and buff goes on the bar in level order, 10 per page
    private void FillDefaultBar()
    {
        for (int p = 0; p < 4; p++) for (int i = 0; i < 10; i++) bar[p, i] = null;
        int n = 0;
        foreach (SkillData s in cls.Skills)
        {
            if (s.kind == SkillKind.Passive) continue;
            if (n >= 40) break;
            bar[n / 10, n % 10] = s;
            n++;
        }
    }

    private int LevelOf(SkillData s)
    {
        int l;
        return skillLevels.TryGetValue(s, out l) ? l : 1;
    }

    private static float LevelScale(int lvl) { return 1f + 0.1f * (lvl - 1); }

    private float ReadyTime(SkillData s)
    {
        float t;
        return readyAt.TryGetValue(s, out t) ? t : 0f;
    }

    // =========================================================
    // UPDATE
    // =========================================================

    private void Update()
    {
        ApplyPending();
        CleanBuffs();
        RecalcTotals();
        popups.RemoveAll(p => Time.time - p.born > 1.1f);

        if (KeyBindings.TextInputActive) return;

        if (Input.GetKeyDown(KeyBindings.Skills)) bookOpen = !bookOpen;
        if (bookOpen && Input.GetKeyDown(KeyBindings.CloseMenus)) bookOpen = false;

        for (int i = 0; i < KeyBindings.HotbarPages.Length && i < 4; i++)
            if (Input.GetKeyDown(KeyBindings.HotbarPages[i])) page = i;

        if (!KeyBindings.Ctrl) // Ctrl + 1..8 is reserved for selecting yourself / party
        {
            for (int i = 0; i < 10; i++)
                if (Input.GetKeyDown(KeyBindings.HotbarSlots[i])) TryCast(bar[page, i]);
        }

        bool wheelClick = Input.GetMouseButtonDown(2) && !UIBlocker.IsOverUI(Input.mousePosition);
        if (wheelClick || Input.GetKeyDown(KeyBindings.WheelSkill)) CastBasicSkill();
    }

    private void ApplyPending()
    {
        if (hasPendingBuild) { hasPendingBuild = false; cls.SetBuild(pendingBuild); }
        if (pendingLevelUp && stats != null) { pendingLevelUp = false; stats.AddXp(stats.XpToNext); }
        if (pendingAssign != null)
        {
            SkillData s = pendingAssign; pendingAssign = null;
            for (int i = 0; i < 10; i++) if (bar[page, i] == null) { bar[page, i] = s; return; }
            bar[page, 9] = s;
        }
    }

    private void CleanBuffs()
    {
        for (int i = buffs.Count - 1; i >= 0; i--)
            if (Time.time >= buffs[i].end) buffs.RemoveAt(i);
    }

    private void RecalcTotals()
    {
        total = new SkillBonus();
        foreach (SkillData s in cls.Skills)
        {
            if (s.kind != SkillKind.Passive) continue;
            if (!cls.IsLearned(s) || !cls.WeaponOk(s)) continue;
            total.AddScaled(s.bonus, LevelScale(LevelOf(s)));
        }
        foreach (ActiveBuff b in buffs)
            total.AddScaled(b.skill.bonus, LevelScale(b.level));
    }

    private void CastBasicSkill()
    {
        foreach (SkillData s in cls.Skills)
            if (s.kind == SkillKind.Attack) { TryCast(s); return; }
    }

    // =========================================================
    // CASTING
    // =========================================================

    public bool TryCast(SkillData s)
    {
        if (s == null || s.kind == SkillKind.Passive) return false;
        if (!cls.IsLearned(s)) { Say(s.skillName + ": needs level " + s.requiredLevel); return false; }
        if (!cls.WeaponOk(s)) { Say(s.skillName + ": needs a " + s.weapon + " equipped"); return false; }
        if (Time.time < ReadyTime(s)) return false;
        if (s.kind == SkillKind.Attack && Time.time < globalReady) return false;
        if (stats != null && stats.Mana < s.mpCost) { Say("Not enough MP"); return false; }

        bool ok = s.kind == SkillKind.Buff ? CastBuff(s) : CastAttack(s);
        if (!ok) return false;

        if (stats != null) stats.SpendMana(s.mpCost);
        readyAt[s] = Time.time + s.cooldown;
        if (s.kind == SkillKind.Attack) globalReady = Time.time + globalCooldown;
        return true;
    }

    private bool CastBuff(SkillData s)
    {
        int lvl = LevelOf(s);
        buffs.RemoveAll(b => b.skill == s || (!string.IsNullOrEmpty(s.exclusiveGroup) && b.skill.exclusiveGroup == s.exclusiveGroup));
        buffs.Add(new ActiveBuff
        {
            skill = s, level = lvl, end = Time.time + s.duration,
            shield = s.bonus.shield * LevelScale(lvl)
        });

        SkillVfx.Ring(transform.position, 1.8f, ClassInfo.ElementTint(s.element));
        if (avatar != null) avatar.PlayBuff();
        Say(s.skillName + " active");
        return true;
    }

    private bool CastAttack(SkillData s)
    {
        if (SafeZone.IsSafe(transform.position)) { Say("No fighting in town"); return false; }

        int lvl = LevelOf(s);
        Transform target = controller.CurrentTarget;
        Health targetHealth = target != null ? target.GetComponent<Health>() : null;
        bool needsTarget = s.target == TargetMode.Single || s.target == TargetMode.AroundTarget;

        if (needsTarget)
        {
            if (target == null || targetHealth == null || targetHealth.IsDead) { Say("Select a target first"); return false; }
            Vector3 flat = target.position - transform.position; flat.y = 0f;
            float size = 0.5f * Mathf.Max(target.lossyScale.x, target.lossyScale.z);
            if (flat.magnitude - size > s.range) { Say(s.skillName + ": target too far"); return false; }
            Face(target.position);
        }
        else if (target != null) Face(target.position);

        Vector3 center = transform.position;
        if (s.target == TargetMode.AroundTarget) center = target.position;

        HashSet<Health> victims = new HashSet<Health>();
        if (s.target == TargetMode.Single) victims.Add(targetHealth);
        else CollectVictims(s, center, victims);

        Color tint = ClassInfo.ElementTint(s.element);
        Vector3 chest = transform.position + Vector3.up * 1.2f;
        if (s.target == TargetMode.Single)
        {
            if (s.range > 5f) SkillVfx.Bolt(chest, target.position + Vector3.up, tint);
            else SkillVfx.Burst(target.position, 1.2f, tint);
        }
        else if (s.target == TargetMode.Frontal)
            SkillVfx.Burst(transform.position + transform.forward * s.radius * 0.5f, s.radius * 0.5f, tint);
        else if (s.target == TargetMode.AroundSelf) { SkillVfx.Ring(transform.position, s.radius, tint); SkillVfx.Burst(transform.position, s.radius * 0.8f, tint); }
        else { if (s.range > 5f) SkillVfx.Bolt(chest, center + Vector3.up, tint); SkillVfx.Ring(center, s.radius, tint); SkillVfx.Burst(center, s.radius * 0.8f, tint); }

        foreach (Health h in victims)
            if (h != null && !h.IsDead) HitTarget(h, s, lvl);

        if (avatar != null) avatar.PlayAttack();
        return true;
    }

    private void CollectVictims(SkillData s, Vector3 center, HashSet<Health> into)
    {
        Collider[] hits = Physics.OverlapSphere(center, s.radius, enemyMask);
        Vector3 fwd = transform.forward; fwd.y = 0f;
        foreach (Collider c in hits)
        {
            Health h = c.GetComponentInParent<Health>();
            if (h == null || h.IsDead || h.gameObject == gameObject) continue;
            if (s.target == TargetMode.Frontal)
            {
                Vector3 to = h.transform.position - transform.position; to.y = 0f;
                if (to.sqrMagnitude > 0.01f && Vector3.Angle(fwd, to) > 55f) continue;
            }
            into.Add(h);
        }
    }

    private void HitTarget(Health h, SkillData s, int lvl)
    {
        for (int i = 0; i < Mathf.Max(1, s.hits); i++)
        {
            bool crit;
            float raw = ComputeDamage(s, lvl, out crit);
            float before = h.Current;
            h.TakeDamage(raw, s.ignoreDefense || (stats != null && stats.IgnoreDefense));
            float dealt = before - h.Current;
            AddPopup(h.transform.position + Vector3.up * (1.9f + 0.35f * i),
                     Mathf.RoundToInt(dealt).ToString() + (crit ? "!" : ""),
                     crit ? new Color(1f, 0.9f, 0.2f) : ClassInfo.ElementTint(s.element), crit);
        }

        if (s.slowSeconds > 0f || s.stunSeconds > 0f || s.burnSeconds > 0f)
        {
            StatusEffects fx = h.GetComponent<StatusEffects>();
            if (fx == null) fx = h.gameObject.AddComponent<StatusEffects>();
            fx.Slow(s.slowPercent, s.slowSeconds);
            fx.Stun(s.stunSeconds);
            fx.Burn(s.burnDamagePerSecond * LevelScale(lvl), s.burnSeconds);
        }
    }

    private float ComputeDamage(SkillData s, int lvl, out bool crit)
    {
        float power = 0f;
        float mult = 1f;
        if (stats != null)
        {
            power = s.IsMagic ? stats.MagicPower : stats.DamageBonus;
            mult = s.IsMagic ? stats.MagicMult : stats.PhysMult;
        }
        float d = s.baseDamage + s.damagePerSkillLevel * (lvl - 1) + s.powerCoef * Mathf.Max(0f, power);
        if (!s.IsMagic) d += total.imbueDamage;

        crit = false;
        if (!s.IsMagic && Random.value * 100f < total.critPct) { d *= critMultiplier; crit = true; }
        return Mathf.Max(1f, d * mult);
    }

    private void Face(Vector3 worldPoint)
    {
        Vector3 d = worldPoint - transform.position; d.y = 0f;
        if (d.sqrMagnitude > 0.01f) transform.rotation = Quaternion.LookRotation(d);
    }

    // =========================================================
    // CALLED BY OTHER SCRIPTS
    // =========================================================

    // PlayerStats: the Frost Shield soaks up damage before your HP does
    public float ConsumeShield(float damage)
    {
        foreach (ActiveBuff b in buffs)
        {
            if (b.shield <= 0f) continue;
            float soak = Mathf.Min(b.shield, damage);
            b.shield -= soak;
            damage -= soak;
            if (damage <= 0f) break;
        }
        return damage;
    }

    public void ShowParry()
    {
        AddPopup(transform.position + Vector3.up * 2.3f, "Parry", new Color(0.6f, 1f, 0.6f), false);
    }

    // PlayerCombat: normal auto-attack hit (damage popup, swing animation)
    public void NotifyBasicHit(Health target, float dealt)
    {
        if (target != null)
            AddPopup(target.transform.position + Vector3.up * 1.9f, Mathf.RoundToInt(dealt).ToString(),
                     HasImbue ? ClassInfo.ElementTint(ImbueElement) : Color.white, false);
        if (avatar != null) avatar.PlayAttack();
    }

    private void AddPopup(Vector3 pos, string text, Color c, bool big)
    {
        popups.Add(new Popup { pos = pos, text = text, color = c, born = Time.time, big = big });
    }

    private void Say(string text)
    {
        message = text;
        messageUntil = Time.time + 2.5f;
    }

    // =========================================================
    // GUI
    // =========================================================

    private void EnsureStyles()
    {
        if (small != null) return;
        small = new GUIStyle(GUI.skin.label) { fontSize = 10, wordWrap = true };
        centered = new GUIStyle(GUI.skin.label) { fontSize = 11, alignment = TextAnchor.MiddleCenter, wordWrap = true };
        popupStyle = new GUIStyle(GUI.skin.label) { fontSize = 16, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        wrap = new GUIStyle(GUI.skin.label) { wordWrap = true };
    }

    private void OnGUI()
    {
        EnsureStyles();
        DrawHotbar();
        DrawBuffList();
        DrawPopups();
        if (bookOpen) DrawBook();

        if (Time.time < messageUntil)
        {
            GUI.color = Color.white;
            GUI.Label(new Rect(Screen.width / 2f - 200f, Screen.height - 150f, 400f, 24f), message, centered);
        }
    }

    private void DrawHotbar()
    {
        float size = 50f, gap = 4f;
        float totalW = 10 * size + 9 * gap;
        float x0 = (Screen.width - totalW) / 2f;
        float y = Screen.height - size - 16f;

        UIBlocker.Register(this, new Rect(x0 - 6f, y - 24f, totalW + 12f, size + 30f));
        Event e = Event.current;

        // page tabs F1..F4
        for (int p = 0; p < 4; p++)
        {
            Rect tab = new Rect(x0 + p * 36f, y - 20f, 34f, 18f);
            GUI.color = p == page ? new Color(0.9f, 0.75f, 0.2f) : new Color(0.25f, 0.25f, 0.3f);
            GUI.DrawTexture(tab, Texture2D.whiteTexture);
            GUI.color = Color.white;
            GUI.Label(tab, "F" + (p + 1), centered);
            if (e.type == EventType.MouseDown && e.button == 0 && tab.Contains(e.mousePosition)) { page = p; e.Use(); }
        }

        for (int i = 0; i < 10; i++)
        {
            Rect r = new Rect(x0 + i * (size + gap), y, size, size);
            SkillData s = bar[page, i];
            DrawSlot(r, s, i);

            if (e.type == EventType.MouseDown && r.Contains(e.mousePosition))
            {
                if (e.button == 0) TryCast(s);
                else if (e.button == 1) bar[page, i] = null;
                e.Use();
            }
        }
    }

    private void DrawSlot(Rect r, SkillData s, int index)
    {
        if (s == null)
        {
            GUI.color = new Color(0f, 0f, 0f, 0.35f);
            GUI.DrawTexture(r, Texture2D.whiteTexture);
        }
        else
        {
            bool active = false;
            foreach (ActiveBuff b in buffs) if (b.skill == s) { active = true; break; }
            if (active)
            {
                GUI.color = new Color(1f, 0.85f, 0.2f);
                GUI.DrawTexture(new Rect(r.x - 2, r.y - 2, r.width + 4, r.height + 4), Texture2D.whiteTexture);
            }

            Color tint = ClassInfo.ElementTint(s.element);
            bool learned = cls.IsLearned(s);
            bool noMana = stats != null && stats.Mana < s.mpCost;
            GUI.color = learned ? new Color(tint.r * 0.45f, tint.g * 0.45f, tint.b * 0.45f) : new Color(0.25f, 0.1f, 0.1f);
            if (learned && noMana) GUI.color = new Color(0.1f, 0.15f, 0.3f);
            GUI.DrawTexture(r, Texture2D.whiteTexture);

            float remain = Mathf.Max(0f, ReadyTime(s) - Time.time);
            if (remain > 0f && s.cooldown > 0f)
            {
                GUI.color = new Color(0f, 0f, 0f, 0.65f);
                GUI.DrawTexture(new Rect(r.x, r.y, r.width, r.height * Mathf.Clamp01(remain / s.cooldown)), Texture2D.whiteTexture);
            }

            GUI.color = Color.white;
            GUI.Label(new Rect(r.x + 1, r.y + 8, r.width - 2, r.height - 20), s.skillName, centered);
            string bottom = !learned ? "Lv " + s.requiredLevel : (remain > 0f ? remain.ToString("0.0") + "s" : s.mpCost + " MP");
            GUI.Label(new Rect(r.x, r.y + r.height - 14, r.width, 14), bottom, centered);
        }

        GUI.color = Color.white;
        GUI.Label(new Rect(r.x + 2, r.y, 20, 14), index == 9 ? "0" : (index + 1).ToString(), small);
    }

    private void DrawBuffList()
    {
        float x = 10f, y = 100f;
        int shown = 0;
        foreach (ActiveBuff b in buffs)
        {
            if (shown++ >= 8) break;
            GUI.color = ClassInfo.ElementTint(b.skill.element);
            GUI.DrawTexture(new Rect(x, y + 3, 10, 10), Texture2D.whiteTexture);
            GUI.color = Color.white;
            string extra = b.shield > 0f ? "  (shield " + Mathf.CeilToInt(b.shield) + ")" : "";
            GUI.Label(new Rect(x + 14, y - 2, 300, 20), b.skill.skillName + "  " + Mathf.CeilToInt(b.end - Time.time) + "s" + extra);
            y += 18f;
        }
    }

    private void DrawPopups()
    {
        Camera cam = Camera.main;
        if (cam == null || Event.current.type != EventType.Repaint) return;
        foreach (Popup p in popups)
        {
            float age = Time.time - p.born;
            Vector3 sp = cam.WorldToScreenPoint(p.pos + Vector3.up * age * 1.3f);
            if (sp.z <= 0f) continue;
            Rect r = new Rect(sp.x - 60f, Screen.height - sp.y - 14f, 120f, 28f);
            popupStyle.fontSize = p.big ? 22 : 16;
            Color c = p.color; c.a = Mathf.Clamp01(1.4f - age);
            GUI.color = new Color(0f, 0f, 0f, c.a);
            GUI.Label(new Rect(r.x + 1, r.y + 1, r.width, r.height), p.text, popupStyle);
            GUI.color = c;
            GUI.Label(r, p.text, popupStyle);
        }
        GUI.color = Color.white;
    }

    // ---------------------------------------------------------- skill book

    private void DrawBook()
    {
        Rect w = new Rect(Screen.width - 410f, 50f, 400f, Screen.height - 160f);
        UIBlocker.Register(this, w);
        GUI.color = Color.white;
        GUILayout.BeginArea(w, GUI.skin.box);

        ClassBuild b = cls.Build;
        GUILayout.BeginHorizontal();
        GUILayout.Label("SKILL BOOK  -  " + ClassInfo.Name(b) + "  (" + (cls.IsStr ? "STR" : "INT") + ", " + ClassInfo.WeaponName(b) + ")");
        GUILayout.FlexibleSpace();
        if (GUILayout.Button("X", GUILayout.Width(28))) bookOpen = false;
        GUILayout.EndHorizontal();
        GUILayout.Label(ClassInfo.TraditionName + " tradition.  " + ClassInfo.Blurb(b), wrap);

        if (devTools)
        {
            GUILayout.Label("TEST TOOLS - switch build:");
            GUILayout.BeginHorizontal();
            for (int i = 0; i < 3; i++) BuildButton((ClassBuild)i);
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            for (int i = 3; i < 6; i++) BuildButton((ClassBuild)i);
            GUILayout.EndHorizontal();
            if (GUILayout.Button("+1 level (test)")) pendingLevelUp = true;
        }

        if (cls.LoadedSkillCount == 0)
            GUILayout.Label("No skills found. Run the menu  MMO > Create Skills  once.", wrap);

        bookScroll = GUILayout.BeginScrollView(bookScroll);
        SkillSection("ATTACK SKILLS", SkillKind.Attack);
        SkillSection("BUFFS", SkillKind.Buff);
        SkillSection("PASSIVES (always on while the weapon fits)", SkillKind.Passive);
        GUILayout.EndScrollView();

        GUILayout.Label("Keys 1-0 cast. F1-F4 change page. Right click a bar slot to clear it.", small);
        GUILayout.EndArea();
    }

    private void BuildButton(ClassBuild b)
    {
        GUI.enabled = b != cls.Build;
        if (GUILayout.Button(ClassInfo.Name(b))) { hasPendingBuild = true; pendingBuild = b; }
        GUI.enabled = true;
    }

    private void SkillSection(string title, SkillKind kind)
    {
        GUILayout.Label(title);
        foreach (SkillData s in cls.Skills)
        {
            if (s.kind != kind) continue;
            bool learned = cls.IsLearned(s);

            GUILayout.BeginVertical(GUI.skin.box);
            GUILayout.BeginHorizontal();
            GUI.contentColor = learned ? ClassInfo.ElementTint(s.element) : Color.gray;
            GUILayout.Label(s.skillName + "   (Lv " + s.requiredLevel + ")");
            GUI.contentColor = Color.white;
            GUILayout.FlexibleSpace();
            if (kind != SkillKind.Passive) GUILayout.Label(s.mpCost + " MP   " + s.cooldown.ToString("0") + "s", small);
            GUILayout.EndHorizontal();

            GUILayout.Label(s.description, small);
            GUILayout.Label(Describe(s), small);

            if (kind != SkillKind.Passive)
            {
                GUI.enabled = learned;
                if (GUILayout.Button(learned ? "Put on bar" : "Locked: level " + s.requiredLevel)) pendingAssign = s;
                GUI.enabled = true;
            }
            GUILayout.EndVertical();
        }
    }

    private string Describe(SkillData s)
    {
        string t = "";
        if (s.kind == SkillKind.Attack)
        {
            t = s.element + " " + (s.IsMagic ? "magic" : "physical") + ", " + s.target;
            if (s.hits > 1) t += ", " + s.hits + " hits";
            t += ", base " + Mathf.RoundToInt(s.baseDamage * Mathf.Max(1, s.hits)) + " dmg";
            if (s.range > 0f && (s.target == TargetMode.Single || s.target == TargetMode.AroundTarget)) t += ", range " + s.range.ToString("0");
            if (s.radius > 0f && s.target != TargetMode.Single) t += ", radius " + s.radius.ToString("0.#");
            if (s.stunSeconds > 0f) t += ", stun " + s.stunSeconds.ToString("0.#") + "s";
            if (s.slowPercent > 0f) t += ", slow " + s.slowPercent.ToString("0") + "%";
            if (s.burnSeconds > 0f) t += ", burn " + s.burnDamagePerSecond.ToString("0") + "/s";
            if (s.ignoreDefense) t += ", ignores defence";
        }
        else
        {
            SkillBonus b = s.bonus;
            if (b.physDamagePct > 0f) t += "Phys dmg +" + b.physDamagePct.ToString("0") + "%  ";
            if (b.magicDamagePct > 0f) t += "Magic dmg +" + b.magicDamagePct.ToString("0") + "%  ";
            if (b.physDefensePct > 0f) t += "Phys def +" + b.physDefensePct.ToString("0") + "%  ";
            if (b.magicDefensePct > 0f) t += "Magic def +" + b.magicDefensePct.ToString("0") + "%  ";
            if (b.parryPct > 0f) t += "Parry +" + b.parryPct.ToString("0") + "%  ";
            if (b.critPct > 0f) t += "Crit +" + b.critPct.ToString("0") + "%  ";
            if (b.moveSpeedPct > 0f) t += "Speed +" + b.moveSpeedPct.ToString("0") + "%  ";
            if (b.imbueDamage > 0f) t += b.imbueElement + " imbue +" + b.imbueDamage.ToString("0") + " per hit  ";
            if (b.shield > 0f) t += "Shield " + b.shield.ToString("0") + "  ";
            if (s.kind == SkillKind.Buff) t += "(" + s.duration.ToString("0") + "s)";
        }
        return t;
    }
}
