using System;
using System.Text;
using UnityEditor;
using UnityEngine;

// Menu: MMO > Create Skills
// Creates (or updates) every skill asset for all 6 builds in Assets/Resources/Skills.
// Safe to run again after you change numbers here: it overwrites the same files.
public static class CreateSkillAssets
{
    private const string Folder = "Assets/Resources/Skills";
    private static ClassBuild cur;
    private static int created, updated;

    [MenuItem("MMO/Create Skills")]
    public static void Run()
    {
        if (!AssetDatabase.IsValidFolder("Assets/Resources")) AssetDatabase.CreateFolder("Assets", "Resources");
        if (!AssetDatabase.IsValidFolder(Folder)) AssetDatabase.CreateFolder("Assets/Resources", "Skills");
        created = 0; updated = 0;

        cur = ClassBuild.Bladesworn; Bladesworn();
        cur = ClassBuild.Warglaive; Warglaive();
        cur = ClassBuild.Marksman; Marksman();
        cur = ClassBuild.Spellblade; Spellblade();
        cur = ClassBuild.Lancecaller; Lancecaller();
        cur = ClassBuild.Skyseer; Skyseer();

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log($"MMO > Create Skills: {created} created, {updated} updated in {Folder}");
    }

    // ------------------------------------------------------------------ helpers

    private static SkillData New(string name, string desc, SkillKind kind, Element el, int lvl)
    {
        SkillData s = ScriptableObject.CreateInstance<SkillData>();
        s.skillName = name; s.description = desc; s.kind = kind; s.element = el; s.requiredLevel = lvl;
        s.classes = new[] { cur };
        s.weapon = ClassInfo.Weapon(cur);
        return s;
    }

    private static void Save(SkillData s)
    {
        StringBuilder safe = new StringBuilder();
        foreach (char c in s.skillName) if (char.IsLetterOrDigit(c)) safe.Append(c);
        string file = cur + "_" + safe;
        s.name = file;
        string path = Folder + "/" + file + ".asset";
        SkillData existing = AssetDatabase.LoadAssetAtPath<SkillData>(path);
        if (existing == null) { AssetDatabase.CreateAsset(s, path); created++; }
        else { EditorUtility.CopySerialized(s, existing); EditorUtility.SetDirty(existing); UnityEngine.Object.DestroyImmediate(s); updated++; }
    }

    // k = strength of the skill (1 = basic hit). Damage is split across the hits.
    private static void Atk(string name, string desc, Element el, TargetMode tm, int lvl, float k, float cd,
                            float range, float radius, int hits, Action<SkillData> extra)
    {
        SkillData s = New(name, desc, SkillKind.Attack, el, lvl);
        s.target = tm; s.range = range; s.radius = radius; s.hits = hits;
        s.baseDamage = Mathf.Round((10f + 3.2f * lvl) * k / hits);
        s.powerCoef = k / hits;
        s.damagePerSkillLevel = Mathf.Round(s.baseDamage * 0.08f * 10f) / 10f;
        s.cooldown = cd;
        s.mpCost = Mathf.RoundToInt((5f + lvl * 1.4f) * (0.6f + k * 0.5f));
        if (extra != null) extra(s);
        Save(s);
    }

    private static void Buf(string name, string desc, Element el, int lvl, int mp, float cd, float dur,
                            string group, Action<SkillBonus> bonus)
    {
        SkillData s = New(name, desc, SkillKind.Buff, el, lvl);
        s.mpCost = mp; s.cooldown = cd; s.duration = dur; s.exclusiveGroup = group;
        s.bonus = new SkillBonus();
        bonus(s.bonus);
        Save(s);
    }

    private static void Pas(string name, string desc, int lvl, Action<SkillBonus> bonus)
    {
        SkillData s = New(name, desc, SkillKind.Passive, Element.Physical, lvl);
        s.mpCost = 0; s.cooldown = 0f;
        s.bonus = new SkillBonus();
        bonus(s.bonus);
        Save(s);
    }

    // ------------------------------------------------------------------ shared packages

    // FULL STR builds: Flame ONLY as an imbue, plus Flame guard (physical defence) and Frost guard (magic defence)
    private static void StrBuffs()
    {
        Buf("Ember Imbue", "Wraps your weapon in Flame: extra Flame damage on every hit for 5 minutes.",
            Element.Flame, 3, 14, 20f, 300f, "Imbue", b => { b.imbueDamage = 8f; b.imbueElement = Element.Flame; });
        Buf("Blazing Imbue", "A stronger Flame imbue. Replaces Ember Imbue.",
            Element.Flame, 20, 30, 30f, 300f, "Imbue", b => { b.imbueDamage = 22f; b.imbueElement = Element.Flame; });
        Buf("Cinder Guard", "Flame protection: raises physical defence for 5 minutes.",
            Element.Flame, 8, 20, 30f, 300f, "FlameGuard", b => { b.physDefensePct = 18f; });
        Buf("Rime Guard", "Frost protection: raises magic defence (and a little physical defence) for 5 minutes.",
            Element.Frost, 14, 24, 30f, 300f, "FrostGuard", b => { b.magicDefensePct = 25f; b.physDefensePct = 6f; });
    }

    // FULL INT builds: Frost Shield (big defence), Storm Surge (magic attack power), Focus (parry ratio), Flame Mantle
    private static void IntBuffs()
    {
        Buf("Frost Shield", "A shell of snow and ice: big physical and magic defence and a layer that soaks up damage.",
            Element.Frost, 5, 30, 60f, 120f, "Shield", b => { b.physDefensePct = 30f; b.magicDefensePct = 30f; b.shield = 80f; });
        Buf("Glacial Bulwark", "A thicker Frost Shield. Replaces Frost Shield.",
            Element.Frost, 22, 70, 90f, 120f, "Shield", b => { b.physDefensePct = 50f; b.magicDefensePct = 50f; b.shield = 300f; });
        Buf("Storm Surge", "Storm energy runs through your spells: magic attack power up.",
            Element.Storm, 8, 28, 90f, 120f, "Surge", b => { b.magicDamagePct = 25f; });
        Buf("Tempest Surge", "A stronger Storm Surge. Replaces Storm Surge.",
            Element.Storm, 24, 60, 120f, 120f, "Surge", b => { b.magicDamagePct = 45f; });
        Buf("Focus", "Concentration: raises your parry ratio.",
            Element.Physical, 12, 26, 90f, 120f, "Focus", b => { b.parryPct = 12f; });
        Buf("Deep Focus", "Deeper concentration. Replaces Focus.",
            Element.Physical, 28, 55, 120f, 120f, "Focus", b => { b.parryPct = 22f; });
        Buf("Flame Mantle", "Flame wraps your body: more magic power and magic defence.",
            Element.Flame, 16, 40, 90f, 120f, "Mantle", b => { b.magicDamagePct = 15f; b.magicDefensePct = 15f; });
    }

    private static Action<SkillData> Burn(float dps, float sec) { return s => { s.burnDamagePerSecond = dps; s.burnSeconds = sec; }; }
    private static Action<SkillData> Slow(float pct, float sec) { return s => { s.slowPercent = pct; s.slowSeconds = sec; }; }
    private static Action<SkillData> Stun(float sec) { return s => { s.stunSeconds = sec; }; }
    private static Action<SkillData> SlowStun(float pct, float sec, float stun) { return s => { s.slowPercent = pct; s.slowSeconds = sec; s.stunSeconds = stun; }; }

    // ------------------------------------------------------------------ FULL STR builds

    private static void Bladesworn()
    {
        Atk("Rending Slash", "A quick, clean cut. Your basic skill.", Element.Physical, TargetMode.Single, 1, 1.0f, 2.5f, 3.5f, 0f, 1, null);
        Atk("Crescent Cut", "A wide cut in front of you.", Element.Physical, TargetMode.Frontal, 6, 1.4f, 7f, 0f, 4.5f, 1, null);
        Atk("Twin Fang Strike", "Two fast strikes on one target.", Element.Physical, TargetMode.Single, 12, 2.4f, 10f, 3.5f, 0f, 2, null);
        Atk("Whirling Edge", "Spin and hit everything around you.", Element.Physical, TargetMode.AroundSelf, 18, 2.2f, 14f, 0f, 4.5f, 1, null);
        Atk("Executioner's Drop", "Your heaviest blow. Stuns the target. Ignores defence.", Element.Physical, TargetMode.Single, 26, 5.0f, 30f, 3.5f, 0f, 1,
            s => { s.stunSeconds = 2f; s.ignoreDefense = true; });
        StrBuffs();
        Buf("Battle Cry", "A roar that raises your physical damage.", Element.Physical, 10, 22, 120f, 90f, "Cry", b => { b.physDamagePct = 20f; });
        Buf("Windstep", "Light footwork: faster movement and better parry.", Element.Physical, 16, 20, 90f, 60f, "Step", b => { b.moveSpeedPct = 25f; b.parryPct = 8f; });
        Pas("Blade Mastery", "Years with the sword: physical damage up.", 5, b => { b.physDamagePct = 10f; });
        Pas("Keen Edge", "A sharper edge: critical chance up.", 10, b => { b.critPct = 8f; });
        Pas("Iron Skin", "Trained body: physical defence up.", 15, b => { b.physDefensePct = 8f; });
        Pas("Duelist's Reflex", "Sharper reactions: parry up.", 20, b => { b.parryPct = 6f; });
    }

    private static void Warglaive()
    {
        Atk("Glaive Strike", "A long thrusting strike. Your basic skill.", Element.Physical, TargetMode.Single, 1, 1.0f, 2.5f, 4f, 0f, 1, null);
        Atk("Wide Sweep", "Sweep the glaive across a wide arc.", Element.Physical, TargetMode.Frontal, 6, 1.3f, 7f, 0f, 5.5f, 1, null);
        Atk("Pinning Lunge", "Pin one target in place for a moment.", Element.Physical, TargetMode.Single, 12, 2.0f, 10f, 4f, 0f, 1, Stun(1.5f));
        Atk("Cyclone Arc", "Whirl the glaive and hit everything near you.", Element.Physical, TargetMode.AroundSelf, 18, 2.0f, 13f, 0f, 5.5f, 1, null);
        Atk("Ground Breaker", "Slam the ground at the target: area damage and a heavy slow.", Element.Physical, TargetMode.AroundTarget, 26, 3.5f, 28f, 5f, 5f, 1, Slow(40f, 4f));
        StrBuffs();
        Buf("Rallying Roar", "Raises physical damage and defence.", Element.Physical, 10, 24, 120f, 90f, "Cry", b => { b.physDamagePct = 18f; b.physDefensePct = 10f; });
        Buf("Gale Stride", "Faster movement and a little crit.", Element.Physical, 16, 20, 90f, 60f, "Step", b => { b.moveSpeedPct = 20f; b.critPct = 5f; });
        Pas("Glaive Mastery", "Years with the glaive: physical damage up.", 5, b => { b.physDamagePct = 10f; });
        Pas("Reach Training", "Better timing at full reach: critical chance up.", 10, b => { b.critPct = 6f; });
        Pas("Thick Hide", "Tough body: physical defence up.", 15, b => { b.physDefensePct = 10f; });
        Pas("Steady Footing", "Balanced stance: parry up.", 20, b => { b.parryPct = 5f; });
    }

    private static void Marksman()
    {
        Atk("Swift Shot", "A fast arrow. Your basic skill.", Element.Physical, TargetMode.Single, 1, 1.0f, 2.0f, 14f, 0f, 1, null);
        Atk("Split Arrow", "Arrows fan out in front of you.", Element.Physical, TargetMode.Frontal, 6, 1.3f, 7f, 0f, 10f, 1, null);
        Atk("Piercing Shot", "An arrow that ignores defence.", Element.Physical, TargetMode.Single, 12, 2.2f, 12f, 16f, 0f, 1, s => { s.ignoreDefense = true; });
        Atk("Arrow Rain", "A rain of arrows over the target area.", Element.Physical, TargetMode.AroundTarget, 18, 2.2f, 16f, 14f, 6f, 1, null);
        Atk("Hawk's Verdict", "Your deadliest shot. Slows the target.", Element.Physical, TargetMode.Single, 26, 5.0f, 30f, 18f, 0f, 1, Slow(50f, 3f));
        StrBuffs();
        Buf("Eagle Focus", "Sharper aim: crit and physical damage up.", Element.Physical, 10, 22, 120f, 90f, "Cry", b => { b.critPct = 12f; b.physDamagePct = 12f; });
        Buf("Light Foot", "Faster movement.", Element.Physical, 16, 18, 90f, 60f, "Step", b => { b.moveSpeedPct = 25f; });
        Pas("Bowmanship", "Years with the bow: physical damage up.", 5, b => { b.physDamagePct = 10f; });
        Pas("Deadeye", "Steady aim: critical chance up.", 10, b => { b.critPct = 10f; });
        Pas("Padded Vest", "Light protection: physical defence up.", 15, b => { b.physDefensePct = 6f; });
        Pas("Evasive Instinct", "Quick dodges: parry up.", 20, b => { b.parryPct = 8f; });
    }

    // ------------------------------------------------------------------ FULL INT builds

    private static void Spellblade()
    {
        Atk("Cinder Slash", "A Flame-edged cut that leaves the target burning.", Element.Flame, TargetMode.Single, 1, 1.0f, 2.5f, 4f, 0f, 1, Burn(6f, 5f));
        Atk("Rime Cut", "A Frost-edged cut that slows the target.", Element.Frost, TargetMode.Single, 4, 1.1f, 4f, 4f, 0f, 1, Slow(30f, 4f));
        Atk("Spark Lash", "A snap of Storm energy along the blade.", Element.Storm, TargetMode.Single, 7, 1.3f, 5f, 4f, 0f, 1, null);
        Atk("Inferno Edge", "A wave of Flame in front of you.", Element.Flame, TargetMode.Frontal, 14, 1.8f, 9f, 0f, 5f, 1, Burn(10f, 5f));
        Atk("Glacier Burst", "Frost erupts around you and freezes enemies for a moment.", Element.Frost, TargetMode.AroundSelf, 16, 2.0f, 13f, 0f, 5f, 1, SlowStun(40f, 4f, 1.5f));
        Atk("Thunder Rend", "Storm tears at the target and everything beside it. Stuns.", Element.Storm, TargetMode.AroundTarget, 20, 2.6f, 16f, 5f, 4f, 1, Stun(2f));
        Atk("Judgment Storm", "A storm of all three elements around you.", Element.Storm, TargetMode.AroundSelf, 28, 3.6f, 28f, 0f, 6f, 1, Burn(14f, 4f));
        IntBuffs();
        Pas("Arcane Bladework", "Magic blade training: magic damage up.", 5, b => { b.magicDamagePct = 10f; });
        Pas("Warded Robes", "Enchanted robes: defence up.", 10, b => { b.physDefensePct = 6f; b.magicDefensePct = 8f; });
        Pas("Sword Reflex", "Blade work sharpens your reactions: parry up.", 15, b => { b.parryPct = 6f; });
        Pas("Elemental Mastery", "Deeper control of the elements: magic damage up.", 22, b => { b.magicDamagePct = 10f; });
    }

    private static void Lancecaller()
    {
        Atk("Ember Spear Toss", "Throw a burning spear of Flame.", Element.Flame, TargetMode.Single, 1, 1.0f, 2.5f, 9f, 0f, 1, Burn(6f, 5f));
        Atk("Icicle Javelin", "A javelin of ice that slows the target.", Element.Frost, TargetMode.Single, 4, 1.1f, 4f, 9f, 0f, 1, Slow(30f, 4f));
        Atk("Static Pierce", "A Storm-charged thrust from a distance.", Element.Storm, TargetMode.Single, 7, 1.3f, 5f, 9f, 0f, 1, null);
        Atk("Pyre Sweep", "Flame bursts around the target and keeps burning.", Element.Flame, TargetMode.AroundTarget, 14, 1.9f, 10f, 9f, 5f, 1, Burn(10f, 5f));
        Atk("Blizzard Ring", "A ring of frost around the target. Heavy slow.", Element.Frost, TargetMode.AroundTarget, 16, 2.0f, 13f, 9f, 6f, 1, Slow(50f, 5f));
        Atk("Skybolt Cascade", "Bolts of Storm fall around the target. Stuns.", Element.Storm, TargetMode.AroundTarget, 20, 2.6f, 16f, 9f, 5f, 1, Stun(1.5f));
        Atk("Tempest Fall", "A huge storm crashes down on the target area.", Element.Storm, TargetMode.AroundTarget, 28, 3.8f, 30f, 10f, 7f, 1, Stun(1f));
        IntBuffs();
        Pas("Spearcaster's Art", "Spell and spear as one: magic damage up.", 5, b => { b.magicDamagePct = 10f; });
        Pas("Woven Wards", "Woven charms: defence up.", 10, b => { b.physDefensePct = 6f; b.magicDefensePct = 8f; });
        Pas("Long-Reach Poise", "Calm at a distance: parry up.", 15, b => { b.parryPct = 6f; });
        Pas("Elemental Mastery", "Deeper control of the elements: magic damage up.", 22, b => { b.magicDamagePct = 10f; });
    }

    private static void Skyseer()
    {
        Atk("Ember Bolt", "A bolt of Flame from your bow. Leaves the target burning.", Element.Flame, TargetMode.Single, 1, 1.0f, 2.0f, 15f, 0f, 1, Burn(6f, 5f));
        Atk("Frost Needle", "An ice arrow that slows the target.", Element.Frost, TargetMode.Single, 4, 1.1f, 4f, 15f, 0f, 1, Slow(30f, 4f));
        Atk("Arc Flash", "A Storm arrow that crackles on impact.", Element.Storm, TargetMode.Single, 7, 1.3f, 5f, 15f, 0f, 1, null);
        Atk("Wildfire Volley", "Fire arrows rain on the target area and burn.", Element.Flame, TargetMode.AroundTarget, 14, 1.9f, 10f, 15f, 5f, 1, Burn(10f, 5f));
        Atk("Whiteout Rain", "Frost arrows fall in an area: slow and a brief freeze.", Element.Frost, TargetMode.AroundTarget, 16, 2.0f, 13f, 15f, 6f, 1, SlowStun(50f, 5f, 1f));
        Atk("Stormbreak Volley", "A volley of Storm arrows. Stuns.", Element.Storm, TargetMode.AroundTarget, 20, 2.5f, 16f, 15f, 5f, 1, Stun(1.5f));
        Atk("Heaven's Ire", "Your strongest spell: a Storm that falls from the sky.", Element.Storm, TargetMode.AroundTarget, 28, 3.8f, 30f, 16f, 7f, 1, Stun(1f));
        IntBuffs();
        Pas("Sky Archery", "Magic arrows: magic damage up.", 5, b => { b.magicDamagePct = 10f; });
        Pas("Feathered Wards", "Feather charms: defence up.", 10, b => { b.physDefensePct = 6f; b.magicDefensePct = 8f; });
        Pas("Windreader", "You read the wind: parry and speed up.", 15, b => { b.parryPct = 6f; b.moveSpeedPct = 5f; });
        Pas("Elemental Mastery", "Deeper control of the elements: magic damage up.", 22, b => { b.magicDamagePct = 10f; });
    }
}
