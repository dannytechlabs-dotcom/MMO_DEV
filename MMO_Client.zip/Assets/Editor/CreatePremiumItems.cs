#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

// Menu: MMO > Create Premium Items
// Creates (or updates) the premium item assets in Assets/Items and, if a "Premium Merchant"
// object exists in the scene, fills its Stock list. Safe to run more than once.
public static class CreatePremiumItems
{
    [MenuItem("MMO/Create Premium Items")]
    public static void Create()
    {
        if (!AssetDatabase.IsValidFolder("Assets/Items"))
            AssetDatabase.CreateFolder("Assets", "Items");

        // Scrolls
        ItemData returnScroll = Make("Return Scroll", ItemType.ReturnScroll, 20, 5, null);
        ItemData reverseScroll = Make("Reverse Return Scroll", ItemType.ReverseReturnScroll, 30, 8, null);
        ItemData resScroll = Make("Resurrection Scroll", ItemType.ResurrectionScroll, 100, 25, null);
        ItemData reactivate = Make("Reactivation Scroll", ItemType.SpiritScroll, 500, 10, d => d.durationDays = 30);

        // Angelic Spirit (normal): 10% damage and absorb, 10% speed, 30 days
        ItemData spirit = Make("Angelic Spirit", ItemType.AngelicSpirit, 2000, 50, d =>
        {
            d.durationDays = 30;
            d.percentDamage = 10f;
            d.percentAbsorb = 10f;
            d.percentPerEnhance = 1f;
            d.percentMoveSpeed = 10f;
            d.healthBonus = 30;
            d.damageBonus = 5;
        });

        // VIP Buffs (60 days) with gift scrolls
        ItemGrant[] gifts =
        {
            new ItemGrant { item = returnScroll, count = 10 },
            new ItemGrant { item = reverseScroll, count = 3 },
            new ItemGrant { item = resScroll, count = 1 }
        };
        ItemData silver = Make("Silver VIP Buff", ItemType.VipBuff, 3000, 10, d => SetVip(d, 10, 10, 50, 5, 10, gifts));
        ItemData gold = Make("Gold VIP Buff", ItemType.VipBuff, 6000, 10, d => SetVip(d, 20, 20, 100, 10, 20, gifts));
        ItemData diamond = Make("Diamond VIP Buff", ItemType.VipBuff, 10000, 10, d => SetVip(d, 25, 25, 150, 15, 25, gifts));

        // Extra equipment for the new slots
        Make("Silver Ring", ItemType.Accessory, 100, 25, d => d.healthBonus = 20);
        Make("Red Cape", ItemType.Avatar, 80, 20, d => d.damageBonus = 2);

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();

        FillMerchant(new[] { spirit, reactivate, silver, gold, diamond, returnScroll, reverseScroll, resScroll });
        Debug.Log("Premium items ready in Assets/Items.");
    }

    private static void SetVip(ItemData d, float dmg, float absorb, float exp, float enhance, int stat, ItemGrant[] gifts)
    {
        d.durationDays = 60;
        d.percentDamage = dmg;
        d.percentAbsorb = absorb;
        d.percentExp = exp;
        d.enhanceSuccessBonus = enhance;
        d.statBonus = stat;
        d.grants = gifts;
    }

    // Finds an existing item asset with this file name anywhere in the project, or creates it
    private static ItemData Make(string name, ItemType type, int buy, int sell, System.Action<ItemData> setup)
    {
        ItemData item = null;
        foreach (string guid in AssetDatabase.FindAssets($"{name} t:ItemData"))
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            if (Path.GetFileNameWithoutExtension(path) != name) continue;
            item = AssetDatabase.LoadAssetAtPath<ItemData>(path);
            break;
        }

        if (item == null)
        {
            item = ScriptableObject.CreateInstance<ItemData>();
            AssetDatabase.CreateAsset(item, $"Assets/Items/{name}.asset");
        }

        item.itemName = name;
        item.type = type;
        item.buyPrice = buy;
        item.sellPrice = sell;
        item.maxStack = 20;
        setup?.Invoke(item);

        EditorUtility.SetDirty(item);
        return item;
    }

    private static void FillMerchant(ItemData[] items)
    {
        GameObject go = GameObject.Find("Premium Merchant");
        if (go == null)
        {
            Debug.Log("No 'Premium Merchant' object in the scene yet: drag the items into its Stock list by hand.");
            return;
        }

        ShopNPC shop = go.GetComponent<ShopNPC>();
        if (shop == null) return;

        SerializedObject so = new SerializedObject(shop);
        SerializedProperty stock = so.FindProperty("stock");
        stock.arraySize = items.Length;
        for (int i = 0; i < items.Length; i++)
            stock.GetArrayElementAtIndex(i).objectReferenceValue = items[i];
        so.ApplyModifiedProperties();

        EditorSceneManager.MarkSceneDirty(go.scene);
        Debug.Log("Premium Merchant stock filled.");
    }
}
#endif
