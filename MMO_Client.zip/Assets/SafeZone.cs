using System.Collections.Generic;
using UnityEngine;

// Put on an empty GameObject at the centre of a town.
// Inside the radius: no player attacks, no skills, enemies stop attacking.
public class SafeZone : MonoBehaviour
{
    [SerializeField] private string zoneName = "Town";
    [SerializeField] private float radius = 25f;

    [Header("Respawn")]
    [SerializeField] private bool respawnHere = true;
    [SerializeField] private Transform respawnPoint; // optional, defaults to this object

    private static readonly List<SafeZone> zones = new List<SafeZone>();
    private static GUIStyle labelStyle;
    private PlayerController player;

    private void OnEnable() { zones.Add(this); }
    private void OnDisable() { zones.Remove(this); }

    public static bool IsSafe(Vector3 position)
    {
        foreach (SafeZone zone in zones)
            if (zone.Contains(position)) return true;
        return false;
    }

    public static bool TryGetRespawn(out Vector3 position)
    {
        foreach (SafeZone zone in zones)
        {
            if (!zone.respawnHere) continue;
            position = zone.respawnPoint != null ? zone.respawnPoint.position : zone.transform.position;
            return true;
        }
        position = Vector3.zero;
        return false;
    }

    private bool Contains(Vector3 p)
    {
        Vector3 d = p - transform.position;
        d.y = 0f;
        return d.sqrMagnitude <= radius * radius;
    }

    private void OnGUI()
    {
        if (player == null) player = FindAnyObjectByType<PlayerController>();
        if (player == null || !Contains(player.transform.position)) return;

        if (labelStyle == null)
        {
            labelStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontStyle = FontStyle.Bold,
                fontSize = 16
            };
            labelStyle.normal.textColor = new Color(0.5f, 1f, 0.5f);
        }

        GUI.Label(new Rect(Screen.width / 2f - 150f, 8f, 300f, 28f), $"{zoneName}  (Safe Zone)", labelStyle);
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = new Color(0.3f, 1f, 0.3f, 0.8f);
        Gizmos.DrawWireSphere(transform.position, radius);
    }
}
