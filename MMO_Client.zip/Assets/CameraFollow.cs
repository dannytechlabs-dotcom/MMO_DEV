using UnityEngine;

// Put on Main Camera. Hold RIGHT mouse and drag to change the view. Mouse wheel zooms.
// F9 cycles the view mode (like Silkroad):
//   FREE            : rotate left/right and up/down
//   LEFT-RIGHT FIXED: only up/down changes
//   UP-DOWN FIXED   : only left/right changes
//   LOCKED          : angle fixed, camera just follows the player
public class CameraFollow : MonoBehaviour
{
    private enum Mode { Free, LeftRightFixed, UpDownFixed, Locked }

    [SerializeField] private Transform target; // leave empty to auto-find the player
    [SerializeField] private float smooth = 8f;
    [SerializeField] private float minZoom = 0.4f;
    [SerializeField] private float maxZoom = 1.6f;
    [SerializeField] private float rotateSpeed = 3f;
    [SerializeField] private float minPitch = 10f;
    [SerializeField] private float maxPitch = 80f;

    private float baseDistance;
    private float startYaw, startPitch;
    private float yaw, pitch;
    private float zoom = 1f;
    private Mode mode = Mode.Free;
    private bool dragging;

    private void Start()
    {
        if (target == null)
        {
            PlayerController pc = FindAnyObjectByType<PlayerController>();
            if (pc != null) target = pc.transform;
        }
        if (target == null) return;

        Vector3 offset = transform.position - target.position;
        baseDistance = offset.magnitude;
        startPitch = Mathf.Asin(offset.y / baseDistance) * Mathf.Rad2Deg;
        startYaw = Mathf.Atan2(offset.x, offset.z) * Mathf.Rad2Deg;
        yaw = startYaw;
        pitch = startPitch;
    }

    private void LateUpdate()
    {
        if (target == null) return;

        if (!KeyBindings.TextInputActive && Input.GetKeyDown(KeyBindings.CameraMode))
            mode = (Mode)(((int)mode + 1) % 4);

        bool overUI = UIBlocker.IsOverUI(Input.mousePosition);

        if (!overUI)
            zoom = Mathf.Clamp(zoom - Input.mouseScrollDelta.y * 0.1f, minZoom, maxZoom);

        // A drag only starts if the right button went down outside any window
        if (Input.GetMouseButtonDown(1)) dragging = !overUI;
        if (Input.GetMouseButtonUp(1)) dragging = false;

        if (mode == Mode.Locked)
        {
            yaw = Mathf.LerpAngle(yaw, startYaw, 6f * Time.deltaTime);
            pitch = Mathf.Lerp(pitch, startPitch, 6f * Time.deltaTime);
        }
        else if (dragging && Input.GetMouseButton(1))
        {
            if (mode != Mode.LeftRightFixed) yaw += Input.GetAxis("Mouse X") * rotateSpeed;
            if (mode != Mode.UpDownFixed)
                pitch = Mathf.Clamp(pitch - Input.GetAxis("Mouse Y") * rotateSpeed, minPitch, maxPitch);
        }

        float cp = Mathf.Cos(pitch * Mathf.Deg2Rad);
        Vector3 dir = new Vector3(Mathf.Sin(yaw * Mathf.Deg2Rad) * cp,
                                  Mathf.Sin(pitch * Mathf.Deg2Rad),
                                  Mathf.Cos(yaw * Mathf.Deg2Rad) * cp);
        Vector3 desired = target.position + dir * baseDistance * zoom;

        if ((desired - transform.position).sqrMagnitude > 400f)
            transform.position = desired;
        else
            transform.position = Vector3.Lerp(transform.position, desired, smooth * Time.deltaTime);

        transform.LookAt(target.position + Vector3.up * 1f);
    }

    private void OnGUI()
    {
        string label = mode switch
        {
            Mode.Free => "FREE VIEW",
            Mode.LeftRightFixed => "LEFT-RIGHT FIXED",
            Mode.UpDownFixed => "UP-DOWN FIXED",
            _ => "LOCKED"
        };
        GUI.Label(new Rect(10, Screen.height - 28, 420, 20),
            $"[{KeyBindings.CameraMode}] Camera: {label}  (hold right mouse to rotate)");
    }
}
