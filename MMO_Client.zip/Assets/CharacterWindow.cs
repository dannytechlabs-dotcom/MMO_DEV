using UnityEngine;

// Put on the Player. Press C to open the character window (stats, STR / INT points).
public class CharacterWindow : MonoBehaviour
{
    private bool open;
    private PlayerStats stats;
    private Health health;

    private void Awake()
    {
        stats = GetComponent<PlayerStats>();
        health = GetComponent<Health>();
    }

    private void Update()
    {
        if (KeyBindings.TextInputActive) return;
        if (Input.GetKeyDown(KeyBindings.Character)) open = !open;
        if (open && Input.GetKeyDown(KeyBindings.CloseMenus)) open = false;
    }

    private void OnGUI()
    {
        GUI.Label(new Rect(Screen.width - 160, 28, 150, 20), $"[{KeyBindings.Character}] Character");
        if (!open || stats == null) return;

        Rect window = new Rect(10, 90, 270, 400);
        UIBlocker.Register(this, window);
        GUILayout.BeginArea(window, GUI.skin.box);

        GUILayout.BeginHorizontal();
        GUILayout.Label("CHARACTER");
        GUILayout.FlexibleSpace();
        if (GUILayout.Button("X", GUILayout.Width(28))) open = false;
        GUILayout.EndHorizontal();

        GUILayout.Label($"Level {stats.Level}");
        GUILayout.Label($"EXP {stats.Xp} / {stats.XpToNext}");
        GUILayout.Label($"HP {health.Current} / {health.Max}");
        GUILayout.Label($"MP {stats.Mana} / {stats.MaxMana}");

        GUILayout.Space(8);
        GUILayout.Label($"Stat points: {stats.StatPoints}");

        bool canSpend = stats.StatPoints > 0;
        GUI.enabled = canSpend;

        GUILayout.BeginHorizontal();
        GUILayout.Label($"STR  {stats.Str}   (HP, physical damage)", GUILayout.Width(210));
        if (GUILayout.Button("+", GUILayout.Width(28))) stats.AddStatPoint(true);
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        GUILayout.Label($"INT  {stats.Int}   (MP, magic power)", GUILayout.Width(210));
        if (GUILayout.Button("+", GUILayout.Width(28))) stats.AddStatPoint(false);
        GUILayout.EndHorizontal();

        GUI.enabled = true;

        GUILayout.Space(8);
        GUILayout.Label($"Physical attack bonus: +{stats.DamageBonus}");
        GUILayout.Label($"Magic power: +{stats.MagicPower}");
        GUILayout.Label($"Damage bonus: +{stats.DamagePercent:0}%   Absorb: {stats.AbsorbPercent:0}%");
        GUILayout.Label($"EXP bonus: +{stats.ExpPercent:0}%");
        GUILayout.Label($"Gold: {stats.Gold}");

        GUILayout.EndArea();
    }
}
