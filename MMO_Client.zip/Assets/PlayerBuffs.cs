using UnityEngine;
using UnityEngine.AI;

// Put on the Player. Handles the Angelic Spirit timer and the VIP Buff.
//  - Angelic Spirit: equip it in the Spirit slot. The timer starts the first time it is equipped
//    and only runs while it is equipped. When it hits zero the bonuses stop until you use a Reactivation Scroll.
//  - VIP Buff (Silver / Gold / Diamond): click the item in the bag to activate it.
public class PlayerBuffs : MonoBehaviour
{
    [Header("Time")]
    [Tooltip("Real seconds that count as ONE game day. 86400 = real time. 60 = testing (1 day = 1 minute).")]
    [SerializeField] private float secondsPerDay = 60f;

    [Header("Limits")]
    [SerializeField] private float maxAbsorbPercent = 75f;

    private Inventory inventory;
    private PlayerStats stats;
    private NavMeshAgent agent;
    private SpiritSkills skills;
    private PlayerSkills playerSkills;
    private float baseSpeed;

    private ItemData vip;
    private float vipSecondsLeft;
    private bool lastSpiritActive, lastVipActive;

    private ItemInstance Spirit => inventory != null ? inventory.Spirit : null;
    public bool SpiritActive => Spirit != null && Spirit.data.type == ItemType.AngelicSpirit && Spirit.secondsLeft > 0f;
    public bool VipActive => vip != null && vipSecondsLeft > 0f;

    private float SpiritDamage => SpiritActive ? Spirit.data.percentDamage + Spirit.level * Spirit.data.percentPerEnhance : 0f;
    private float SpiritAbsorb => SpiritActive ? Spirit.data.percentAbsorb + Spirit.level * Spirit.data.percentPerEnhance : 0f;

    public float DamagePercent => SpiritDamage + (VipActive ? vip.percentDamage : 0f) + (skills != null ? skills.DivineDamagePercent : 0f);
    public float AbsorbPercent => Mathf.Min(maxAbsorbPercent, SpiritAbsorb + (VipActive ? vip.percentAbsorb : 0f));
    public float ExpPercent => VipActive ? vip.percentExp : 0f;
    public float EnhanceBonus => VipActive ? vip.enhanceSuccessBonus / 100f : 0f;   // 0.10 = +10 points
    public int StatBonus => VipActive ? vip.statBonus : 0;
    public float MovePercent => (SpiritActive ? Spirit.data.percentMoveSpeed : 0f) + (skills != null ? skills.DivineMovePercent : 0f) + (playerSkills != null ? playerSkills.MoveSpeedPct : 0f);
    public bool IgnoreDefense => skills != null && skills.IgnoringDefense;

    private void Awake()
    {
        inventory = GetComponent<Inventory>();
        stats = GetComponent<PlayerStats>();
        agent = GetComponent<NavMeshAgent>();
        skills = GetComponent<SpiritSkills>();
        playerSkills = GetComponent<PlayerSkills>();
        if (agent != null) baseSpeed = agent.speed;
    }

    private void Update()
    {
        ItemInstance spirit = Spirit;
        if (spirit != null && spirit.data.type == ItemType.AngelicSpirit)
        {
            if (spirit.secondsLeft < 0f)
                spirit.secondsLeft = spirit.data.durationDays * secondsPerDay;   // first equip: start the timer
            else if (spirit.secondsLeft > 0f)
                spirit.secondsLeft = Mathf.Max(0f, spirit.secondsLeft - Time.deltaTime);
        }

        if (VipActive) vipSecondsLeft = Mathf.Max(0f, vipSecondsLeft - Time.deltaTime);

        // Re-calculate stats when a buff switches on or off (VIP adds STR/INT)
        bool s = SpiritActive, v = VipActive;
        if (s != lastSpiritActive || v != lastVipActive)
        {
            lastSpiritActive = s;
            lastVipActive = v;
            if (stats != null) stats.Recalculate(false);
        }

        if (agent != null) agent.speed = baseSpeed * (1f + MovePercent / 100f);
    }

    public bool TryActivateVip(ItemData item, out string result)
    {
        // Gift scrolls (reverse return, resurrection, return-to-town...) go into the bag first
        bool gifted = false;
        if (item.grants != null && inventory != null)
        {
            foreach (ItemGrant g in item.grants)
            {
                if (g.item != null && !inventory.CanAdd(g.item, g.count))
                {
                    result = "Not enough bag space for the VIP gift scrolls. Free some slots first.";
                    return false;
                }
            }
            foreach (ItemGrant g in item.grants)
            {
                if (g.item == null) continue;
                inventory.TryAdd(g.item, g.count);
                gifted = true;
            }
        }

        float add = item.durationDays * secondsPerDay;

        if (VipActive && vip == item)
        {
            vipSecondsLeft += add;
            result = $"{item.itemName} extended by {item.durationDays} days.";
        }
        else
        {
            result = VipActive ? $"{vip.itemName} replaced by {item.itemName}." : $"{item.itemName} activated!";
            vip = item;
            vipSecondsLeft = add;
        }

        if (gifted) result += " Gift scrolls added to your bag.";
        if (stats != null) stats.Recalculate(false);
        return true;
    }

    public bool TryReactivateSpirit(ItemData scroll, out string result)
    {
        ItemInstance spirit = Spirit;
        if (spirit == null || spirit.data.type != ItemType.AngelicSpirit)
        {
            result = "Equip an Angelic Spirit first.";
            return false;
        }

        spirit.secondsLeft = scroll.durationDays * secondsPerDay;
        result = $"Angelic Spirit reactivated for {scroll.durationDays} days.";
        return true;
    }

    // Shows time in game days (so it looks right even in test mode)
    public string FormatTime(float secondsLeft)
    {
        float gameSeconds = secondsLeft / secondsPerDay * 86400f;
        int d = (int)(gameSeconds / 86400f);
        int h = (int)(gameSeconds % 86400f / 3600f);
        int m = (int)(gameSeconds % 3600f / 60f);
        return $"{d}d {h}h {m}m";
    }

    // Buff list at the top of the screen
    private void OnGUI()
    {
        float x = Screen.width / 2f - 150f;
        float y = 10f;

        ItemInstance spirit = Spirit;
        if (spirit != null && spirit.data.type == ItemType.AngelicSpirit)
        {
            string text = spirit.secondsLeft == 0f
                ? $"{spirit.Name}: EXPIRED (use a Reactivation Scroll)"
                : $"{spirit.Name}: +{SpiritDamage:0}% dmg, +{SpiritAbsorb:0}% absorb  ({FormatTime(Mathf.Max(0f, spirit.secondsLeft))})";
            Line(x, ref y, text, spirit.secondsLeft == 0f ? Color.red : new Color(0.6f, 0.9f, 1f));
        }

        if (skills != null)
        {
            if (skills.DivineSecondsLeft > 0f)
                Line(x, ref y, $"Divine Omnipotence: +{skills.DivineDamagePercent:0}% dmg, +{skills.DivineMovePercent:0}% speed  ({skills.DivineSecondsLeft:0}s)", new Color(1f, 1f, 0.6f));
            if (skills.IgnoreSecondsLeft > 0f)
                Line(x, ref y, $"Ignore Monster Defence  ({skills.IgnoreSecondsLeft:0}s)", new Color(1f, 0.6f, 0.4f));
        }

        if (VipActive)
            Line(x, ref y, $"{vip.itemName}: +{vip.percentDamage:0}% dmg, +{vip.percentAbsorb:0}% absorb, +{vip.percentExp:0}% EXP  ({FormatTime(vipSecondsLeft)})", new Color(1f, 0.85f, 0.3f));
    }

    private static void Line(float x, ref float y, string text, Color color)
    {
        GUI.color = Color.black;
        GUI.DrawTexture(new Rect(x, y, 300f, 20f), Texture2D.whiteTexture);
        GUI.color = color;
        GUI.Label(new Rect(x + 4f, y, 296f, 20f), text);
        GUI.color = Color.white;
        y += 22f;
    }
}
