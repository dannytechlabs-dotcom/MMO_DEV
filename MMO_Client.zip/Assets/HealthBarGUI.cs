using UnityEngine;

[RequireComponent(typeof(Health))]
public class HealthBarGUI : MonoBehaviour
{
    [SerializeField] private float heightOffset = 2.3f;
    [SerializeField] private float barWidth = 70f;
    [SerializeField] private float barHeight = 8f;

    private Health health;
    private PlayerController player;
    private Camera cam;

    private string rankLabel = "";
    private Color rankColor = Color.white;
    private GUIStyle labelStyle;

    private void Awake()
    {
        health = GetComponent<Health>();
        cam = Camera.main;
    }

    // Called by MonsterRank for Champion, Giant, Titan and Unique
    public void SetRank(string label, Color color)
    {
        rankLabel = label;
        rankColor = color;
    }

    private void OnGUI()
    {
        if (health == null || health.IsDead || cam == null) return;
        if (player == null) player = FindAnyObjectByType<PlayerController>();

        // Taller monsters get their bar higher up
        float offset = heightOffset * transform.localScale.y;
        Vector3 screen = cam.WorldToScreenPoint(transform.position + Vector3.up * offset);
        if (screen.z < 0f) return; // behind the camera

        float x = screen.x - barWidth / 2f;
        float y = Screen.height - screen.y; // GUI y is flipped

        bool targeted = player != null && player.CurrentTarget == transform;
        float pct = (float)health.Current / health.Max;

        // Border (yellow when targeted), background, fill
        GUI.color = targeted ? Color.yellow : Color.black;
        GUI.DrawTexture(new Rect(x - 2, y - 2, barWidth + 4, barHeight + 4), Texture2D.whiteTexture);
        GUI.color = new Color(0.2f, 0f, 0f);
        GUI.DrawTexture(new Rect(x, y, barWidth, barHeight), Texture2D.whiteTexture);
        GUI.color = Color.red;
        GUI.DrawTexture(new Rect(x, y, barWidth * pct, barHeight), Texture2D.whiteTexture);
        GUI.color = Color.white;

        // Rank name above the bar (only special monsters have one)
        if (!string.IsNullOrEmpty(rankLabel))
        {
            if (labelStyle == null)
            {
                labelStyle = new GUIStyle(GUI.skin.label)
                {
                    alignment = TextAnchor.MiddleCenter,
                    fontStyle = FontStyle.Bold
                };
            }

            Rect r = new Rect(x - 40, y - 22, barWidth + 80, 18);
            labelStyle.normal.textColor = Color.black;
            GUI.Label(new Rect(r.x + 1, r.y + 1, r.width, r.height), rankLabel, labelStyle);
            labelStyle.normal.textColor = rankColor;
            GUI.Label(r, rankLabel, labelStyle);
        }
    }
}
