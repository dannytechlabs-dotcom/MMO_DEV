using System.Collections.Generic;
using UnityEngine;

public class ShopNPC : NPC
{
    [Header("Shop")]
    [SerializeField] private ItemData[] stock;
    [SerializeField] private float closeDistance = 5f;

    private bool open;
    private Inventory inventory;
    private PlayerStats stats;
    private Transform player;
    private string message = "";
    private Vector2 buyScroll;
    private Vector2 sellScroll;

    public override void Interact(GameObject playerObject)
    {
        player = playerObject.transform;
        inventory = playerObject.GetComponent<Inventory>();
        stats = playerObject.GetComponent<PlayerStats>();

        open = true;
        message = "Welcome! Click an item to buy or sell.";
    }

    private void Update()
    {
        if (!open) return;

        // Close with Escape or when the player walks away
        if (Input.GetKeyDown(KeyCode.Escape) || player == null ||
            Vector3.Distance(player.position, transform.position) > closeDistance)
        {
            open = false;
        }
    }

    protected override void OnGUI()
    {
        base.OnGUI(); // name tag
        DrawShop();
    }

    private void DrawShop()
    {
        if (!open || inventory == null || stats == null) return;

        float w = 560f;
        float h = 420f;
        Rect window = new Rect((Screen.width - w) / 2f, (Screen.height - h) / 2f, w, h);
        UIBlocker.Register(this, window);
        GUILayout.BeginArea(window, GUI.skin.box);

        GUILayout.BeginHorizontal();
        GUILayout.Label($"{npcName.ToUpper()}   -   Your gold: {stats.Gold}");
        if (GUILayout.Button("X", GUILayout.Width(30))) open = false;
        GUILayout.EndHorizontal();

        if (!string.IsNullOrEmpty(message)) GUILayout.Label(message);

        GUILayout.BeginHorizontal();

        // ---- BUY ----
        GUILayout.BeginVertical(GUILayout.Width(w / 2f - 12f));
        GUILayout.Label("BUY");
        buyScroll = GUILayout.BeginScrollView(buyScroll);
        if (stock != null)
        {
            foreach (ItemData item in stock)
            {
                if (item == null) continue;
                if (GUILayout.Button($"{item.itemName}  -  {item.buyPrice}g"))
                    inventory.TryBuy(item, 1, out message);
            }
        }
        GUILayout.EndScrollView();
        GUILayout.EndVertical();

        // ---- SELL ----
        GUILayout.BeginVertical(GUILayout.Width(w / 2f - 12f));
        GUILayout.Label($"SELL (bag {inventory.Bag.Count} items)");
        sellScroll = GUILayout.BeginScrollView(sellScroll);
        foreach (ItemInstance slot in new List<ItemInstance>(inventory.Bag))
        {
            if (GUILayout.Button($"{slot.Label}  -  {slot.data.sellPrice}g each"))
                inventory.TrySell(slot, out message);
        }
        GUILayout.EndScrollView();
        GUILayout.EndVertical();

        GUILayout.EndHorizontal();
        GUILayout.EndArea();
    }
}
