using UnityEngine;
using UnityEngine.AI;

// Put on the Player. Used by the Return Scroll (instant teleport to town) and the
// Reverse Return Scroll (back to where you last used a return scroll or died).
public class PlayerTeleport : MonoBehaviour
{
    private NavMeshAgent agent;
    private PlayerController controller;
    private Vector3 savedPoint;
    private bool hasSavedPoint;

    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        controller = GetComponent<PlayerController>();
    }

    public void SaveReturnPoint(Vector3 point)
    {
        savedPoint = point;
        hasSavedPoint = true;
    }

    public bool TryReturnToTown(out string result)
    {
        if (!SafeZone.TryGetRespawn(out Vector3 town))
        {
            result = "There is no town to return to.";
            return false;
        }
        if (SafeZone.IsSafe(transform.position))
        {
            result = "You are already in town.";
            return false;
        }

        SaveReturnPoint(transform.position);
        Warp(town);
        result = "Teleported to town.";
        return true;
    }

    public bool TryReverseReturn(out string result)
    {
        if (!hasSavedPoint)
        {
            result = "No saved location yet. Use a Return Scroll or die first.";
            return false;
        }

        Warp(savedPoint);
        result = "Teleported back to your saved location.";
        return true;
    }

    private void Warp(Vector3 point)
    {
        agent.Warp(point);
        agent.ResetPath();
        if (controller != null) controller.ClearTargets();
    }
}
