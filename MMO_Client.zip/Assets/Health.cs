using System;
using UnityEngine;
using Unity.Netcode;

// Works in two modes:
//  - NOT spawned on the network (solo play, objects without a Network Object): health is a normal local number.
//  - Spawned on the network: the SERVER owns the number (NetworkVariable), clients only read it.
// Public API is the same as before, plus TakeDamage(amount, ignoreDefense).
public class Health : NetworkBehaviour
{
    [Header("Health Settings")]
    [SerializeField] private float maxHealth = 100f;

    public NetworkVariable<float> currentHealth =
        new NetworkVariable<float>(
            100f,
            NetworkVariableReadPermission.Everyone,
            NetworkVariableWritePermission.Server
        );

    private float localHealth;
    private bool localReady;

    public float Current { get { EnsureLocal(); return IsSpawned ? currentHealth.Value : localHealth; } }
    public float Max => maxHealth;
    public float CurrentHealth => Current;

    public bool IsDead => Current <= 0f;

    public float DefensePercent { get; private set; }

    public Func<float, float> DamageFilter { get; set; }

    public event Action OnDied;

    // Not on the network = we decide. On the network = only the server decides.
    private bool HasAuthority => !IsSpawned || IsServer;

    private void EnsureLocal()
    {
        if (localReady) return;
        localReady = true;
        localHealth = maxHealth;
    }

    public override void OnNetworkSpawn()
    {
        base.OnNetworkSpawn();
        EnsureLocal();

        if (IsServer)
            currentHealth.Value = Mathf.Clamp(localHealth, 0f, maxHealth);

        currentHealth.OnValueChanged += HandleHealthChanged;
    }

    public override void OnNetworkDespawn()
    {
        currentHealth.OnValueChanged -= HandleHealthChanged;
        base.OnNetworkDespawn();
    }

    private void HandleHealthChanged(float oldHealth, float newHealth)
    {
        if (newHealth <= 0f && oldHealth > 0f)
            Die();
    }

    // The one place where health changes
    private void SetCurrent(float value)
    {
        EnsureLocal();
        float old = Current;

        localHealth = value;
        if (IsSpawned) currentHealth.Value = value;   // triggers HandleHealthChanged -> Die

        if (!IsSpawned && value <= 0f && old > 0f)
            Die();
    }

    public void TakeDamage(float amount)
    {
        TakeDamage(amount, null);
    }

    // Used by the player's attacks: ignoreDefense = true skips the monster's defence
    public void TakeDamage(float amount, bool ignoreDefense)
    {
        ApplyDamage(amount, ignoreDefense);
    }

    public void TakeDamage(float amount, object source)
    {
        ApplyDamage(amount, false);
    }

    private void ApplyDamage(float amount, bool ignoreDefense)
    {
        if (!HasAuthority)
            return;

        if (amount <= 0f || IsDead)
            return;

        if (DamageFilter != null)
            amount = DamageFilter(amount);

        if (amount <= 0f)
            return;

        if (!ignoreDefense && DefensePercent > 0f)
            amount *= Mathf.Clamp01(1f - DefensePercent / 100f);

        SetCurrent(Mathf.Max(0f, Current - amount));
    }

    public void Heal(float amount)
    {
        if (!HasAuthority)
            return;

        if (amount <= 0f || IsDead)
            return;

        SetCurrent(Mathf.Min(maxHealth, Current + amount));
    }

    private void Die()
    {
        if (!HasAuthority)
            return;

        if (Current > 0f)
            return;

        Debug.Log($"{gameObject.name} died.");

        OnDied?.Invoke();
    }

    public void Revive()
    {
        if (!HasAuthority)
            return;

        SetCurrent(maxHealth);
    }

    public void Revive(float healthPercent)
    {
        if (!HasAuthority)
            return;

        healthPercent = Mathf.Clamp01(healthPercent);

        SetCurrent(maxHealth * healthPercent);
    }

    public void SetMaxHealth(float value)
    {
        SetMaxHealth(value, false);
    }

    public void SetMaxHealth(float value, bool fillHealth)
    {
        if (!HasAuthority)
            return;

        EnsureLocal();
        maxHealth = Mathf.Max(1f, value);

        if (fillHealth)
            SetCurrent(maxHealth);
        else if (Current > maxHealth)
            SetCurrent(maxHealth);
    }

    public void SetHealthFromDatabase(float value)
    {
        if (!HasAuthority)
            return;

        SetCurrent(Mathf.Clamp(value, 0f, maxHealth));
    }

    public void SetDefensePercent(float value)
    {
        if (!HasAuthority)
            return;

        DefensePercent = Mathf.Clamp(
            value,
            0f,
            100f
        );
    }
}
