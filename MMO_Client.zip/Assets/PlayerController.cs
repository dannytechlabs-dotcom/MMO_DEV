using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class PlayerController : MonoBehaviour
{
    [Header("Click Settings")]
    [SerializeField] private LayerMask groundMask;
    [SerializeField] private LayerMask enemyMask;
    [SerializeField] private LayerMask npcMask;
    [SerializeField] private float maxClickDistance = 200f;
    [SerializeField] private float doubleClickTime = 0.3f;

    [Header("Combat")]
    [SerializeField] private float attackRange = 2f;

    private NavMeshAgent agent;
    private Camera cam;
    private Transform target;     // selected enemy (yellow border)
    private bool attacking;       // true after double-click on the target
    private NPC npcTarget;
    private float lastClickTime = -10f;
    private Transform lastClickedEnemy;

    public Transform CurrentTarget => target;
    public bool IsAttacking => attacking && target != null;

    public void ClearTargets()
    {
        target = null;
        attacking = false;
        npcTarget = null;
    }

    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        cam = Camera.main;

        // If the Ground Mask was left empty in the Inspector, use the layer called "Ground"
        if (groundMask.value == 0)
        {
            groundMask = LayerMask.GetMask("Ground");
            Debug.LogWarning("PlayerController: Ground Mask was empty, using layer 'Ground'.");
        }
    }

    private void Update()
    {
        HandleClick();
        HandleTargetChase();
        HandleNpcApproach();
    }

    private void HandleClick()
    {
        // LEFT click = main click (move, select, talk to NPC, double-click to attack)
        if (!Input.GetMouseButtonDown(0)) return;
        if (UIBlocker.IsOverUI(Input.mousePosition)) return; // clicked a window

        Ray ray = cam.ScreenPointToRay(Input.mousePosition);

        // Enemies first
        if (Physics.Raycast(ray, out RaycastHit enemyHit, maxClickDistance, enemyMask))
        {
            Transform clicked = enemyHit.transform;
            bool isDouble = clicked == lastClickedEnemy && Time.time - lastClickTime <= doubleClickTime;

            target = clicked;
            npcTarget = null;
            attacking = isDouble || KeyBindings.Ctrl;   // double click or Ctrl+click attacks

            lastClickedEnemy = clicked;
            lastClickTime = Time.time;
            return;
        }

        lastClickedEnemy = null;

        // NPCs: walk up to them and interact
        if (Physics.Raycast(ray, out RaycastHit npcHit, maxClickDistance, npcMask))
        {
            NPC npc = npcHit.collider.GetComponentInParent<NPC>();
            if (npc != null)
            {
                ClearTargets();
                npcTarget = npc;
                return;
            }
        }

        // Ground: walk there (the click is snapped to the nearest walkable spot)
        if (TryGetGroundPoint(ray, out Vector3 point))
        {
            ClearTargets();

            if (!agent.isOnNavMesh)
            {
                Debug.LogWarning("PlayerController: the Player is not on the NavMesh. Re-bake the NavMesh (select Ground > Bake).");
                return;
            }

            agent.isStopped = false;
            agent.SetDestination(point);
        }
    }

    private bool TryGetGroundPoint(Ray ray, out Vector3 point)
    {
        Vector3 hitPoint;

        if (Physics.Raycast(ray, out RaycastHit groundHit, maxClickDistance, groundMask))
        {
            hitPoint = groundHit.point;
        }
        else if (Physics.Raycast(ray, out RaycastHit anyHit, maxClickDistance * 2f, ~0, QueryTriggerInteraction.Ignore))
        {
            // Not on the Ground layer: still try to walk to the nearest walkable spot
            hitPoint = anyHit.point;
            Debug.Log($"Click hit '{anyHit.collider.name}' on layer '{LayerMask.LayerToName(anyHit.collider.gameObject.layer)}', not on the Ground layer.");
        }
        else
        {
            Debug.Log("Click hit nothing. The ground needs a collider on the Ground layer.");
            point = default;
            return false;
        }

        if (NavMesh.SamplePosition(hitPoint, out NavMeshHit nav, 5f, NavMesh.AllAreas))
        {
            point = nav.position;
            return true;
        }

        Debug.Log($"Clicked {hitPoint}, but there is no walkable NavMesh within 5 units. Re-bake the NavMesh.");
        point = default;
        return false;
    }

    private void HandleTargetChase()
    {
        if (!IsAttacking) return;

        float distance = Vector3.Distance(transform.position, target.position);

        if (distance > attackRange)
        {
            agent.isStopped = false;
            agent.SetDestination(target.position);
        }
        else
        {
            agent.isStopped = true;
            Vector3 dir = (target.position - transform.position).normalized;
            dir.y = 0f;
            if (dir != Vector3.zero)
                transform.rotation = Quaternion.LookRotation(dir);
        }
    }

    private void HandleNpcApproach()
    {
        if (npcTarget == null) return;

        float distance = Vector3.Distance(transform.position, npcTarget.transform.position);

        if (distance > npcTarget.interactRange)
        {
            agent.isStopped = false;
            agent.SetDestination(npcTarget.transform.position);
        }
        else
        {
            agent.isStopped = true;
            agent.ResetPath();

            Vector3 dir = npcTarget.transform.position - transform.position;
            dir.y = 0f;
            if (dir != Vector3.zero)
                transform.rotation = Quaternion.LookRotation(dir);

            NPC npc = npcTarget;
            npcTarget = null;
            npc.Interact(gameObject);
        }
    }
}
