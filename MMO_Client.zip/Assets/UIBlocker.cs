using System.Collections.Generic;
using UnityEngine;

// Windows register their screen rectangle here every frame.
// PlayerController and CameraFollow ask IsOverUI so a click or scroll on a window
// does not also move the player or zoom the camera.
public static class UIBlocker
{
    private struct Entry { public Rect rect; public int frame; }
    private static readonly Dictionary<object, Entry> windows = new Dictionary<object, Entry>();

    // Call from OnGUI while the window is open (GUI coordinates, y from top)
    public static void Register(object owner, Rect guiRect)
    {
        windows[owner] = new Entry { rect = guiRect, frame = Time.frameCount };
    }

    // screenPos = Input.mousePosition (y from bottom)
    public static bool IsOverUI(Vector2 screenPos)
    {
        Vector2 gui = new Vector2(screenPos.x, Screen.height - screenPos.y);
        foreach (Entry e in windows.Values)
        {
            if (Time.frameCount - e.frame > 2) continue; // window closed
            if (e.rect.Contains(gui)) return true;
        }
        return false;
    }
}
