using UnityEngine;

[RequireComponent(typeof(Health))]
public class PlayerStats : MonoBehaviour
{
    [Header("Level scaling")]
    [SerializeField] private int baseMaxHealth = 100;
    [SerializeField] private int healthPerLevel = 20;
    [SerializeField] private int damagePerLevel = 3;
    [SerializeField] private int baseMaxMana = 50;
    [SerializeField] private int manaPerLevel = 10;

    [Header("Stat points (Silkroad style: STR and INT)")]
    [SerializeField] private int statPointsPerLevel = 3;
    [SerializeField] private int healthPerStr = 5;
    [SerializeField] private int manaPerInt = 5;

    private const int BaseStat = 10;

    private Health health;
    private Inventory inventory;
    private PlayerBuffs buffs;
    private PlayerSkills skillSys;
    private float manaFraction;

    [Header("Mana")]
    [SerializeField] private float manaRegenPercentPerSecond = 1.5f;

    public int Level { get; private set; } = 1;
    public int Xp { get; private set; }
    public int Gold { get; private set; }

    private int baseStr = BaseStat;
    private int baseInt = BaseStat;

    public int Str =>
        baseStr + (buffs != null ? buffs.StatBonus : 0);

    public int Int =>
        baseInt + (buffs != null ? buffs.StatBonus : 0);

    public int StatPoints { get; private set; }
    public int Mana { get; private set; }
    public int MaxMana { get; private set; }

    public int XpToNext =>
        Mathf.RoundToInt(50f * Mathf.Pow(Level, 1.5f));

    public int DamageBonus =>
        (Level - 1) * damagePerLevel
        + (Str - BaseStat)
        + (inventory != null ? inventory.WeaponDamage : 0);

    public int MagicPower =>
        (Level - 1) * damagePerLevel
        + (Int - BaseStat) * 2;

    // =========================================================
    // BUFFS
    // =========================================================

    public float DamagePercent =>
        buffs != null ? buffs.DamagePercent : 0f;

    public float AbsorbPercent =>
        Mathf.Min(75f, (buffs != null ? buffs.AbsorbPercent : 0f)
                       + (skillSys != null ? skillSys.PhysDefensePct : 0f));

    public float ExpPercent =>
        buffs != null ? buffs.ExpPercent : 0f;

    public float PhysMult =>
        1f + (DamagePercent + (skillSys != null ? skillSys.PhysDamagePct : 0f)) / 100f;

    public float MagicMult =>
        1f + (DamagePercent + (skillSys != null ? skillSys.MagicDamagePct : 0f)) / 100f;

    public bool IgnoreDefense =>
        buffs != null && buffs.IgnoreDefense;

    // =========================================================
    // DAMAGE ABSORPTION
    // =========================================================

    public float AbsorbDamage(float damage)
    {
        if (damage <= 0f)
            return 0f;

        // Focus / parry: the hit misses completely
        if (skillSys != null && Random.value * 100f < Mathf.Min(60f, skillSys.ParryPct))
        {
            skillSys.ShowParry();
            return 0f;
        }

        float reduced = damage * (1f - AbsorbPercent / 100f);

        // Frost Shield soaks up damage before HP does
        if (skillSys != null)
            reduced = skillSys.ConsumeShield(reduced);

        if (reduced <= 0f)
            return 0f;

        return Mathf.Max(1f, reduced);
    }

    // =========================================================
    // AWAKE
    // =========================================================

    private void Awake()
    {
        health = GetComponent<Health>();
        inventory = GetComponent<Inventory>();
        buffs = GetComponent<PlayerBuffs>();
        skillSys = GetComponent<PlayerSkills>();

        if (health != null)
            health.DamageFilter = AbsorbDamage;
    }

    // =========================================================
    // MANA (used by skills)
    // =========================================================

    public bool SpendMana(int amount)
    {
        if (amount <= 0)
            return true;

        if (Mana < amount)
            return false;

        Mana -= amount;
        return true;
    }

    private void Update()
    {
        if (MaxMana <= 0 || Mana >= MaxMana)
            return;

        manaFraction += MaxMana * manaRegenPercentPerSecond / 100f * Time.deltaTime;
        int add = (int)manaFraction;

        if (add > 0)
        {
            Mana = Mathf.Min(MaxMana, Mana + add);
            manaFraction -= add;
        }
    }

    // =========================================================
    // START
    // =========================================================

    private void Start()
    {
        Recalculate(true);
    }

    // =========================================================
    // RECALCULATE STATS
    // =========================================================

    public void Recalculate(bool fullHeal)
    {
        if (health == null)
            return;

        int armor =
            inventory != null
                ? inventory.ArmorHealth
                : 0;

        int maxHealth =
            baseMaxHealth
            + (Level - 1) * healthPerLevel
            + armor
            + (Str - BaseStat) * healthPerStr;

        health.SetMaxHealth(
            maxHealth,
            fullHeal
        );

        MaxMana =
            baseMaxMana
            + (Level - 1) * manaPerLevel
            + (Int - BaseStat) * manaPerInt;

        Mana =
            fullHeal
                ? MaxMana
                : Mathf.Min(Mana, MaxMana);
    }

    // =========================================================
    // STAT POINT
    // =========================================================

    public bool AddStatPoint(bool toStr)
    {
        if (StatPoints <= 0)
            return false;

        StatPoints--;

        if (toStr)
            baseStr++;
        else
            baseInt++;

        Recalculate(false);

        return true;
    }

    // =========================================================
    // GOLD
    // =========================================================

    public void AddGold(int amount)
    {
        Gold += amount;

        Debug.Log(
            $"+{amount} gold (total {Gold})"
        );
    }

    public bool SpendGold(int amount)
    {
        if (amount < 0)
            return false;

        if (Gold < amount)
            return false;

        Gold -= amount;

        return true;
    }

    // =========================================================
    // XP
    // =========================================================

    public void AddXp(int amount)
    {
        if (amount <= 0)
            return;

        amount = Mathf.RoundToInt(
            amount * (1f + ExpPercent / 100f)
        );

        Xp += amount;

        Debug.Log(
            $"+{amount} XP ({Xp}/{XpToNext})"
        );

        while (Xp >= XpToNext)
        {
            Xp -= XpToNext;

            Level++;

            StatPoints += statPointsPerLevel;

            Recalculate(true);

            Debug.Log(
                $"LEVEL UP! Now level {Level} " +
                $"(+{statPointsPerLevel} stat points, press C)"
            );
        }
    }

    // =========================================================
    // GUI
    // =========================================================

    private void OnGUI()
    {
        if (health == null)
            return;

        GUI.color = Color.black;

        GUI.DrawTexture(
            new Rect(10, 10, 300, 50),
            Texture2D.whiteTexture
        );

        GUI.color = Color.white;

        GUI.Label(
            new Rect(16, 12, 290, 20),
            $"Lv {Level}  HP {health.Current}/{health.Max}  " +
            $"MP {Mana}/{MaxMana}  Gold {Gold}"
        );

        GUI.color = new Color(
            0.2f,
            0.2f,
            0.2f
        );

        GUI.DrawTexture(
            new Rect(16, 38, 288, 10),
            Texture2D.whiteTexture
        );

        GUI.color = new Color(
            0.3f,
            0.6f,
            1f
        );

        float xpProgress =
            XpToNext > 0
                ? (float)Xp / XpToNext
                : 0f;

        GUI.DrawTexture(
            new Rect(
                16,
                38,
                288f * xpProgress,
                10
            ),
            Texture2D.whiteTexture
        );

        GUI.color = Color.white;

        if (StatPoints > 0)
        {
            GUI.Label(
                new Rect(16, 62, 290, 20),
                $"{StatPoints} stat points to spend - " +
                $"press [{KeyBindings.Character}]"
            );
        }
    }
}