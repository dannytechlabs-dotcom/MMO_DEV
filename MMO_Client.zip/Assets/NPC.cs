using UnityEngine;

public class NPC : MonoBehaviour
{
    public string npcName = "Merchant";
    public float interactRange = 3f;
    [SerializeField] private float nameHeight = 2.3f;

    private static GUIStyle tagStyle;

    // Called by PlayerController when the player arrives
    public virtual void Interact(GameObject player)
    {
        Debug.Log($"{npcName} says hello");
    }

    protected virtual void OnGUI()
    {
        Camera cam = Camera.main;
        if (cam == null) return;

        Vector3 screen = cam.WorldToScreenPoint(transform.position + Vector3.up * nameHeight);
        if (screen.z < 0f) return;

        if (tagStyle == null)
        {
            tagStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontStyle = FontStyle.Bold
            };
            tagStyle.normal.textColor = Color.yellow;
        }

        GUI.Label(new Rect(screen.x - 75f, Screen.height - screen.y - 10f, 150f, 20f), npcName, tagStyle);
    }
}
