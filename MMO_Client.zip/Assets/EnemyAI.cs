using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
[RequireComponent(typeof(Health))]
public class EnemyAI : MonoBehaviour
{
    [SerializeField] private float detectRange = 8f;
    [SerializeField] private float attackRange = 2f;
    [SerializeField] private int damage = 5;
    [SerializeField] private float attackCooldown = 1.5f;
    [Tooltip("Prints why a monster does or does not attack (untick when everything works)")]
    [SerializeField] private bool debugLog = true;

    // Set by MonsterRank (Champion 1.3x, Giant 1.8x, Titan 2.5x, Unique 4x)
    public float DamageMultiplier = 1f;

    private NavMeshAgent agent;
    private Health ownHealth;
    private Transform player;
    private Health playerHealth;
    private float nextAttackTime;
    private float nextFindTime;
    private float nextDebugTime;
    private StatusEffects fx;   // added by skills (slow / stun / burn)

    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        ownHealth = GetComponent<Health>();

    }

    // Looks for the player again until found (useful if the player appears after the monsters)
    private bool EnsurePlayer()
    {
        if (player != null && playerHealth != null) return true;
        if (Time.time < nextFindTime) return false;
        nextFindTime = Time.time + 1f;

        PlayerController pc = FindAnyObjectByType<PlayerController>();
        if (pc != null)
        {
            player = pc.transform;
            playerHealth = pc.GetComponent<Health>();
        }
        return player != null && playerHealth != null;
    }

    private void Update()
    {
        if (ownHealth.IsDead || !EnsurePlayer()) return;

        if (fx == null) fx = GetComponent<StatusEffects>();
        if (fx != null && fx.Stunned) { agent.isStopped = true; return; }

        // Dead player or player standing in a safe zone: do nothing
        if (playerHealth.IsDead || SafeZone.IsSafe(player.position))
        {
            agent.isStopped = true;
            if (debugLog && Time.time >= nextDebugTime)
            {
                nextDebugTime = Time.time + 3f;
                Debug.Log($"[EnemyAI] {name} idle: playerDead={playerHealth.IsDead} playerInSafeZone={SafeZone.IsSafe(player.position)}");
            }
            return;
        }

        // Flat distance (ignores height), so scaled-up monsters measure the same way as the safe zone
        Vector3 flat = player.position - transform.position;
        flat.y = 0f;
        float distance = flat.magnitude;

        if (debugLog && distance <= detectRange && Time.time >= nextDebugTime)
        {
            nextDebugTime = Time.time + 1.5f;
            Debug.Log($"[EnemyAI] {name} dist={distance:F1} attackRange={attackRange} playerHP={playerHealth.Current:F0}/{playerHealth.Max:F0} nextAttackIn={Mathf.Max(0f, nextAttackTime - Time.time):F1}");
        }

        if (distance > detectRange)
        {
            agent.isStopped = true; // player too far, stand still
        }
        else if (distance > attackRange)
        {
            agent.isStopped = false;
            agent.SetDestination(player.position);
        }
        else
        {
            agent.isStopped = true;
            FacePlayer();

            if (Time.time >= nextAttackTime)
            {
                nextAttackTime = Time.time + attackCooldown;
                int dealt = Mathf.Max(1, Mathf.RoundToInt(damage * DamageMultiplier));
                float before = playerHealth.Current;
                playerHealth.TakeDamage(dealt);
                if (debugLog) Debug.Log($"[EnemyAI] {name} hits player for {dealt}: HP {before:F0} -> {playerHealth.Current:F0}");
            }
        }
    }

    private void FacePlayer()
    {
        Vector3 dir = (player.position - transform.position).normalized;
        dir.y = 0f;
        if (dir != Vector3.zero)
            transform.rotation = Quaternion.LookRotation(dir);
    }
}
