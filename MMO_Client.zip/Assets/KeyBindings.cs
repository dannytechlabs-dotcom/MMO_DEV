using UnityEngine;

// ONE place for every key in the game (based on the Silkroad control tables).
// To change a key, change it here. A remap screen can be added later.
public static class KeyBindings
{
    // Set to true while the player is typing in chat, so hotkeys stay quiet
    public static bool TextInputActive;

    // ---- Windows (remappable in Silkroad) ----
    public static KeyCode Character   = KeyCode.C;   // stats, HP, MP, STR, INT
    public static KeyCode Inventory   = KeyCode.I;   // bag, equipment, gold
    public static KeyCode Skills      = KeyCode.S;   // skill book
    public static KeyCode Action      = KeyCode.A;   // action list (sit, emotes)
    public static KeyCode Quests      = KeyCode.Q;   // quest list
    public static KeyCode Community   = KeyCode.U;   // guild, whisper, friends
    public static KeyCode Party       = KeyCode.P;   // party
    public static KeyCode Academy     = KeyCode.L;   // academy
    public static KeyCode Alchemy     = KeyCode.Y;   // alchemy (Angelic Spirit upgrade later)
    public static KeyCode AutoPotion  = KeyCode.T;   // auto-potion settings
    public static KeyCode Help        = KeyCode.H;
    public static KeyCode PartyAssign = KeyCode.E;   // party matching
    public static KeyCode StallNetwork = KeyCode.F;  // stall network
    public static KeyCode FullMap     = KeyCode.M;
    public static KeyCode ItemShop    = KeyCode.F10; // premium shop (VIP Buff items later)
    public static KeyCode HideUI      = KeyCode.F12;

    // ---- Basic keys (fixed in Silkroad) ----
    public static KeyCode CloseMenus  = KeyCode.Escape;
    public static KeyCode Chat        = KeyCode.Return;
    public static KeyCode Screenshot  = KeyCode.Print;
    public static KeyCode CameraMode  = KeyCode.F9;
    public static KeyCode Berserk     = KeyCode.Tab;
    public static KeyCode SitStand    = KeyCode.N;
    public static KeyCode PickUp      = KeyCode.G;   // "agarrar"
    public static KeyCode ShowDropNames = KeyCode.Z;
    public static KeyCode HideOthers  = KeyCode.V;   // hide all players/monsters except you
    public static KeyCode ReplyWhisper = KeyCode.R;
    public static KeyCode WheelSkill  = KeyCode.X;   // same as mouse-wheel click
    public static KeyCode MountSwitch = KeyCode.W;   // transport / pet selection

    // ---- Angelic Spirit skills (temporary keys until the hotbar exists) ----
    public static KeyCode SpiritSkill1 = KeyCode.F5;      // Divine Omnipotence (hotbar owns 1..0 now)
    public static KeyCode SpiritSkill2 = KeyCode.F6;      // Ignore monster defence
    public static KeyCode Resurrect    = KeyCode.B;       // use Resurrection Scroll on the death screen

    // ---- Movement (arrows, fixed in Silkroad) ----
    public static KeyCode MoveForward = KeyCode.UpArrow;
    public static KeyCode MoveBack    = KeyCode.DownArrow;
    public static KeyCode TurnLeft    = KeyCode.LeftArrow;
    public static KeyCode TurnRight   = KeyCode.RightArrow;

    // ---- Hotbar: keys 1..9,0 and F1-F4 to switch the 4 bars ----
    public static readonly KeyCode[] HotbarSlots =
    {
        KeyCode.Alpha1, KeyCode.Alpha2, KeyCode.Alpha3, KeyCode.Alpha4, KeyCode.Alpha5,
        KeyCode.Alpha6, KeyCode.Alpha7, KeyCode.Alpha8, KeyCode.Alpha9, KeyCode.Alpha0
    };
    public static readonly KeyCode[] HotbarPages = { KeyCode.F1, KeyCode.F2, KeyCode.F3, KeyCode.F4 };
    // Space + 1..0 = extension bar. Ctrl+1 = select yourself, Ctrl+2..8 = party members.

    // ---- Pets / transport keys (later) ----
    // Insert = info, Home = mount / deactivate, PageUp = dismiss, Delete = follow,
    // End = pet attack, PageDown = pet aggressive/defensive

    // ---- Modifiers with mouse ----
    // Ctrl + left click = attack, Alt + left click = force PK, Shift + left click = split stack
    public static bool Ctrl  => Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl);
    public static bool Alt   => Input.GetKey(KeyCode.LeftAlt) || Input.GetKey(KeyCode.RightAlt);
    public static bool Shift => Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
}
