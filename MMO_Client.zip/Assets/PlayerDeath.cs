using System.Collections;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(Health))]
[RequireComponent(typeof(NavMeshAgent))]
public class PlayerDeath : MonoBehaviour
{
    [SerializeField] private float respawnDelay = 3f;

    private Health health;
    private NavMeshAgent agent;
    private Vector3 spawnPoint;
    private bool dead;
    private bool resurrect;
    private Inventory inventory;
    private PlayerTeleport teleport;

    [Header("Resurrection Scroll")]
    [SerializeField] private float resurrectHealthPercent = 0.5f; // revive with half HP

    private void Awake()
    {
        health = GetComponent<Health>();
        agent = GetComponent<NavMeshAgent>();
        spawnPoint = transform.position;
        inventory = GetComponent<Inventory>();
        teleport = GetComponent<PlayerTeleport>();
    }

    private void Update()
    {
        if (dead && Input.GetKeyDown(KeyBindings.Resurrect)) TryResurrect();
    }

    private void TryResurrect()
    {
        if (!dead || resurrect || inventory == null) return;
        if (inventory.ConsumeOne(ItemType.ResurrectionScroll)) resurrect = true;
    }

    private void OnEnable()
    {
        health.OnDied += HandleDeath;
    }

    private void OnDisable()
    {
        health.OnDied -= HandleDeath;
    }

    private void HandleDeath()
    {
        StartCoroutine(RespawnRoutine());
    }

    private IEnumerator RespawnRoutine()
    {
        dead = true;
        resurrect = false;
        SetControl(false);
        agent.ResetPath();

        // A Reverse Return Scroll later brings you back to where you died
        if (teleport != null) teleport.SaveReturnPoint(transform.position);

        float waited = 0f;
        while (waited < respawnDelay && !resurrect)
        {
            waited += Time.deltaTime;
            yield return null;
        }

        if (resurrect)
        {
            // Revive on the spot with a Resurrection Scroll
            health.Revive(resurrectHealthPercent);
            agent.isStopped = false;
            SetControl(true);
            dead = false;
            yield break;
        }

        // Respawn in town if there is one, otherwise at the start point
        Vector3 point = SafeZone.TryGetRespawn(out Vector3 townPoint) ? townPoint : spawnPoint;
        agent.Warp(point);
        health.Revive();
        SetControl(true);

        PlayerController controller = GetComponent<PlayerController>();
        if (controller != null) controller.ClearTargets();

        dead = false;
    }

    private void SetControl(bool enabled)
    {
        var controller = GetComponent<PlayerController>();
        var combat = GetComponent<PlayerCombat>();
        var skills = GetComponent<PlayerSkills>();
        if (controller != null) controller.enabled = enabled;
        if (combat != null) combat.enabled = enabled;
        if (skills != null) skills.enabled = enabled;
    }

    private void OnGUI()
    {
        if (!dead) return;
        GUI.color = Color.red;
        GUI.Label(new Rect(Screen.width / 2f - 60, Screen.height / 2f - 10, 200, 30), "YOU DIED - respawning...");
        GUI.color = Color.white;

        int scrolls = inventory != null ? inventory.CountOf(ItemType.ResurrectionScroll) : 0;
        if (scrolls > 0 && !resurrect)
        {
            if (GUI.Button(new Rect(Screen.width / 2f - 130, Screen.height / 2f + 25, 260, 32),
                    $"Use Resurrection Scroll ({scrolls})  [{KeyBindings.Resurrect}]"))
                TryResurrect();
        }
    }
}
