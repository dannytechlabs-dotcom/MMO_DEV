using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class EnemySpawner : MonoBehaviour
{
    [SerializeField] private GameObject enemyPrefab;
    [SerializeField] private int count = 3;
    [SerializeField] private float spawnRadius = 6f;
    [SerializeField] private float respawnDelay = 10f;

    [Header("Special monsters (chance in percent for each spawn)")]
    [SerializeField] private float championChance = 12f;
    [SerializeField] private float giantChance = 5f;
    [SerializeField] private float titanChance = 2f;
    [SerializeField] private float uniqueChance = 0.5f;
    [Tooltip("Multiplies all chances above. Set 5 or 10 to see special monsters more often while testing.")]
    [SerializeField] private float chanceMultiplier = 1f;

    [Header("Testing: force every spawn to one rank")]
    [SerializeField] private bool forceRank = false;
    [SerializeField] private MonsterRank.Rank forcedRank = MonsterRank.Rank.Titan;

    private void Start()
    {
        for (int i = 0; i < count; i++)
            Spawn();
    }

    private void Spawn()
    {
        if (enemyPrefab == null) return;

        Vector3 random = transform.position + Random.insideUnitSphere * spawnRadius;
        random.y = transform.position.y;

        Vector3 pos = transform.position;
        if (NavMesh.SamplePosition(random, out NavMeshHit hit, 3f, NavMesh.AllAreas))
            pos = hit.position;

        GameObject enemy = Instantiate(enemyPrefab, pos, Quaternion.identity);

        MonsterRank rank = enemy.GetComponent<MonsterRank>();
        if (rank == null) rank = enemy.AddComponent<MonsterRank>();
        rank.Apply(forceRank ? forcedRank : RollRank());

        Health h = enemy.GetComponent<Health>();
        if (h != null) h.OnDied += () => StartCoroutine(RespawnAfterDelay());
    }

    // Rarest rank is checked first, so a roll can never give two ranks
    private MonsterRank.Rank RollRank()
    {
        float m = Mathf.Max(0f, chanceMultiplier);
        float roll = Random.value * 100f;
        float threshold = 0f;

        threshold += uniqueChance * m;   if (roll < threshold) return MonsterRank.Rank.Unique;
        threshold += titanChance * m;    if (roll < threshold) return MonsterRank.Rank.Titan;
        threshold += giantChance * m;    if (roll < threshold) return MonsterRank.Rank.Giant;
        threshold += championChance * m; if (roll < threshold) return MonsterRank.Rank.Champion;
        return MonsterRank.Rank.General;
    }

    private IEnumerator RespawnAfterDelay()
    {
        yield return new WaitForSeconds(respawnDelay);
        Spawn();
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, spawnRadius);
    }
}
